
/**
 * @purpose Calculates the trajectory of a projectile fruit for the Cantelope 
 * Catapult Contest. These calculations are based on launch angles and launch
 * velocities.
 *
 * @author (Jack Moran)
 * @version (11/29/17)
 * 
 */
public class Fruitapult
{
  private double meters;
  
  /**
   * Constructor for objects of type Fruitapult
   */
  Fruitapult()
  {}
  
  /**
   * Mutator method to calculate the projectile distance
   * @param launch launch speed
   * @param angle launch angle
   */
  public double trajCalc (int launch, double angle)
  {
    return (Math.pow(launch, 2) * Math.sin(2 * angle)) / 9.8;
  }
  
  /**
   * Mutator method to convert miles per hour to meters per second
   * @param miles miles per hour
   */
  public double mps (int miles)
  {
    return miles * 0.44704;
  }
}