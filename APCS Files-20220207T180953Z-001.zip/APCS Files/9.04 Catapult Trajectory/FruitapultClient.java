
/**
 * @purpose Applies the Fruitapult program to an array of values and displays
 * the results.
 *
 * @author (Jack Moran)
 * @version (11/29/17)
 * 
 */
public class FruitapultClient
{
  public static void main (String [] args)
  {
    //sets up arrays and fruitapult object
    Fruitapult fruit = new Fruitapult();

    int [] speeds = {20, 25, 30, 35, 40, 45};
    int [] angles = {25, 30, 35, 40, 45, 50};
    double [][] distances = new double [6][6];
    
    for (int i = 0; i < angles.length; i++)
    {
      for (int index = 0; index < angles.length; index++)
      {
        distances [i][index] = fruit.trajCalc(speeds[i], 
        Math.toRadians(angles[index]));
      }
    }
    
    //calculates and prints the results
    System.out.println("                          Projectile Distance(meters)");
    System.out.print("   MPH");
    for (int i = 0; i < angles.length; i++)
      System.out.printf("%8d deg", angles[i]);
      
    System.out.println();
    System.out.print("=====================================================");
    System.out.println("=========================");
    
    for (int i = 0; i < angles.length; i++)
    {
      System.out.printf("%6d", speeds[i]);
      for (int index = 0; index < angles.length; index++)
      System.out.printf("%12.2f", distances [i][index]);
      
      System.out.println();
    }
  }
}
