
/**
 * Purpose: To create text that resembles a Student Info Card.
 *
 * @author Jack Moran
 * @version August 21 2017
 */
public class StudentInfoCard
{
   public static void main(String[]args)
   {
       System.out.println("Student Info Card");
       System.out.println();      
       System.out.print("Name: Jack Moran");
       System.out.print("Birthday: April 28, 2001");
       System.out.print("Age: 16");
       System.out.println();
       System.out.println("School: FLVS");
       System.out.print("Grade: 11");
       System.out.print("City: Tampa, FL");
       System.out.println();
       System.out.println("Home Phone: 813-961-4656");
       System.out.print("Available: 2:00pm-6:00pm 7 days a week");
       System.out.println("Cell: 813-480-8791 - best number to call or text");
       System.out.println("Email: jdm23133@gmail.com");
       System.out.println();
       System.out.println("Mom's contact info");
       System.out.println("Cell: 813-833-4888 - available any time for call or text");
       System.out.println("Email: smoran6@yahoo.com");
       System.out.println();
       System.out.println("Highest Math Class: Alegbra II, it was alright.");
       System.out.println("Programming experience: I've worked with HTML5 and CSS3 on a beginner's level");
       System.out.println();
       System.out.println("I'm taking this course to help me prepare for college. It will raise my GPA, prepare me for the difficulty of the classes and help me learn the ways of Game Design, my career of choice.");
       
  }
}
