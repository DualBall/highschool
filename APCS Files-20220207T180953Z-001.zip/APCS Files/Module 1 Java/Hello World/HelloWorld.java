
/**
 * Purpose: Display a "Hello, World!" message to the screen.
 *
 * @author Jack Moran
 * @version August 21, 2017
 */
public class HelloWorld
{
  public static void main (String [] args)
   {
       System.out.print(3.14);
       System.out.println();
       System.out.println(3.14);
    }//end of main method
}//end of class
