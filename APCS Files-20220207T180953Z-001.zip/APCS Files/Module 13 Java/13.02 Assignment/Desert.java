
/**
 * @purpose Defines a Desert.
 *
 * @author (Jack Moran)
 * @version (1/31/18)
 */
public class Desert extends Terrain
{
    private int desertTemp;

    /**
     * Constructor for objects of type Desert
     */
    public Desert(int l, int w, int dt)
    {
      super(l, w);  
      desertTemp = dt;
    }

    /**
     * Prints the desert temperature.
     */
    public String getDTemp()
    {
      return " and is " + desertTemp + " degrees";
    }
}
