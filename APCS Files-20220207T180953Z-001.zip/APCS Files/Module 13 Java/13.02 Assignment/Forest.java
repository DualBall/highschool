
/**
 * @purpose Defines a Forest, serving as a superclass to specialized types
 * of Forests.
 *
 * @author (Jack Moran)
 * @version (1/31/18)
 */
public class Forest extends Terrain
{
    private int treeNum;

    /**
     * Constructor for objects of type Forest.
     */
    public Forest(int l, int w, int tn)
    {
       super(l, w);
       treeNum = tn;
    }

    /**
     * Prints the number of trees.
     */
    public String getTrees()
    {
        return " and has " + treeNum + " trees";
    }
}
