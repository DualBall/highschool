
/**
 * @purpose Defines a Jungle.
 *
 * @author (Jack Moran)
 * @version (1/31/18)
 */
public class Jungle extends Forest
{
    private int monkeyNum;

    /**
     * Constructor for objects of type Jungle.
     */
    public Jungle(int l, int w, int tn, int mn)
    {
       super(l, w, tn);
       monkeyNum = mn;
    }

    /**
     * Prints the number of animals.
     */
    public String getMonkeys()
    {
        return " with " + monkeyNum + " monkeys";
    }
}
