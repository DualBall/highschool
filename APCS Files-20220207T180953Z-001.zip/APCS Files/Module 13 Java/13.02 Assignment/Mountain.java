
/**
 * @purpose Defines a Mountain, serving as a superclass to specialized types
 * of Mountains.
 *
 * @author (Jack Moran)
 * @version (1/31/18)
 */
public class Mountain extends Terrain
{
    private int mountNum;

    /**
     * Constructor for objects of type Mountain
     */
    public Mountain(int l, int w, int mn)
    {
      super(l, w);  
      mountNum = mn;
    }

    /**
     * Prints the number of mountains.
     */
    public String getMountains()
    {
      return " and has " + mountNum + " mountains";
    }
}
