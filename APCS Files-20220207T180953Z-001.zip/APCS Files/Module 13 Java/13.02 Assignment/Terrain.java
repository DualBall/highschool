

 /**
 * @purpose Defines a basic Terrain, serving as a superclass to specialized
 * types of Terrain.
 *
 * @author (Jack Moran)
 * @version (1/31/18)
 */

public class Terrain
{
    private int length, width;

    /**
     * Constructor for objects of type Terrain.
     */
    public Terrain(int l, int w)
    {
        length = l;
        width = w;
    }

    /**
     * Prints the land's dimensions.
     */
    public String getTerrainSize()
    {
        return "Land has dimensions " + length + " X " + width;
    }
}