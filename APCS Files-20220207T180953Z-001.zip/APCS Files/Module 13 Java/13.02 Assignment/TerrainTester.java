
/**
 * @purpose Runs the Terrain program and its various subclasses.
 *
 * @author (Jack Moran)
 * @version (a version number or a date)
 */
public class TerrainTester
{
  public static void main (String [] args)
  {
    //constructs the various kinds of terrain
    Terrain terra = new Terrain(50, 50);
    Mountain mount = new Mountain(50, 50, 7);
    WinterMountain wMount = new WinterMountain(50, 50, 7, 23);
    Forest trees = new Forest(50, 50, 55);
    Jungle jTrees = new Jungle(50, 50, 55, 24);
    Desert sand = new Desert(50, 50, 98);
    
    //runs the printing methods of the various classes
    System.out.println("Bland " + terra.getTerrainSize());
    System.out.println();
    System.out.println("Hyrule " + mount.getTerrainSize() + mount.getMountains());
    System.out.println();
    System.out.println("Skyrim " + wMount.getTerrainSize() + wMount.getMountains() + wMount.getWMTemp());
    System.out.println();
    System.out.println("Minecraft " + trees.getTerrainSize() + trees.getTrees());
    System.out.println();
    System.out.println("DK " + jTrees.getTerrainSize() + jTrees.getTrees() + jTrees.getMonkeys());
    System.out.println();
    System.out.println("Boring " + sand.getTerrainSize() + sand.getDTemp());
  }
}
