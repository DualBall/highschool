
/**
 * Defines a WinterMountain.
 *
 * @author (Jack Moran)
 * @version (1/31/18)
 */
public class WinterMountain extends Mountain
{
    private int mountTemp;

    /**
     * Constructor for objects of type WinterMountain
     */
    public WinterMountain(int l, int w, int mn, int mt)
    {
      super(l, w, mn);
      mountTemp = mt;
    }

    /**
     * Prints the number of mountains.
     */
    public String getWMTemp()
    {
      return " and temperature " + mountTemp + " degrees";
    }
}
