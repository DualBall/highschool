
/**
 * Runs the Circle2 program and its various subclasses.
 *
 * @author (Jack Moran)
 * @version (2/1/18)
 */
import java.util.ArrayList;
public class Circle2Tester
{
  public static String showCenter(Circle2 c)
  {
    return "For this " + c.getName() + " the " + c.getCenter();
  }
  
  public static void main (String [] args)
  {
    //constructs various kinds of circles and stores them in an ArrayList
    ArrayList<Circle2> circles = new ArrayList<Circle2>();
    circles.add(new Circle2(0, 0, 5));
    circles.add(new Cylinder2(1, 1, 6, 10));
    circles.add(new Oval2(2, 2, 7, 14));
    circles.add(new OvalCylinder2(3, 3, 8, 16, 11));
    
    //prints the results
    System.out.println(showCenter(circles.get(0)));
    System.out.println(showCenter((Cylinder2)circles.get(1)));
    System.out.println(showCenter((Oval2)circles.get(2)));
    System.out.println(showCenter((OvalCylinder2)circles.get(3)));
  }
}
