/**
 * @purpose Defines a Box object by extending the Rectangle object.
 *
 * @author Jack Moran
 * @version 02/05/18
 */
public class BoxV4 extends RectangleV4
{
    // instance variables
    private int height;

    // Constructor for objects of class Box
    public BoxV4(int l, int w, int h)
    {
        // call superclass
        super(l, w);

        // initialize instance variables
        height = h;
    }

    // return the height
    public int getHeight()
    {
        return height;
    }

    // String to display when object is printed.
    public String toString()
    {
        return "Box - " + getLength() + " X " + getWidth() + " X " + height;
    }
    
    // Tests if two shapes are equal
    public boolean equals(RectangleV4 r) 
    { 
        if (!(r instanceof BoxV4)) 
        return false;

        BoxV4 a = (BoxV4)r;
        return a.getLength() == getLength() && a.getWidth() == getWidth();
    } 
}