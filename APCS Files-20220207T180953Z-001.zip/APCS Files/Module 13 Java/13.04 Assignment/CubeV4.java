
/**
 * @purpose Defines a Cube object by extending the Box object.
 *
 * @author Jack Moran
 * @version 02/05/18
 */
public class CubeV4 extends BoxV4
{
    // instance variables
    private int side;

    // Constructor for objects of class Box
    public CubeV4(int s)
    {
        // call superclass
        super(s, s, s);

        // initialize instance variables
        side = s;
    }

    // String to display when object is printed.
    public String toString()
    {
      return "Cube - " + side + " X " + side + " X " + side;
    }
}