/**
 * @purpose Defines a Rectangle object.
 *
 * @author Jack Moran
 * @version 02/05/18
 */
public class RectangleV4
{
    // instance variables
    private int length;
    private int width;

    // Constructor for objects of class Rectangle
    public RectangleV4(int l, int w)
    {
        // initialize instance variables
        length = l;
        width = w;
    }

    // return the height
    public int getLength()
    {
        return length;
    }

    // return the width
    public int getWidth()
    {
        return width;
    }

    // String to display when object is printed.
    public String toString()
    {
        return "Rectangle - " + length + " X " + width;
    }
    
    // Tests if two shapes are equal
    public boolean equals(RectangleV4 r) 
    { 
        if (!(r instanceof RectangleV4)) 
        return false;
        
        if (r instanceof BoxV4)
        return false;

        RectangleV4 a = (RectangleV4)r;
        return a.getLength() == getLength() && a.getWidth() == getWidth();
    } 
}