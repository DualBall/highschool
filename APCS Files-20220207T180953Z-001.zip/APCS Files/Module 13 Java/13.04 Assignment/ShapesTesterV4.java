/**
 * @purpose Runs the Rectangle class and its various subclasses.
 *
 * @author Jack Moran
 * @version 02/5/18
 */
import java.util.ArrayList;
public class ShapesTesterV4
{
    public static void showEffectBoth(RectangleV4 r)
    {
        System.out.println(r);
    }

    public static void main(String []args)
    {
        RectangleV4 one = new RectangleV4(5, 20);
        RectangleV4 two = new BoxV4(4, 10, 5);
        RectangleV4 three = new CubeV4(4);
        RectangleV4 four = new SquarePrismV4(12, 1);
        RectangleV4 five = new TriangularPrismV4(18, 1, 1);
        
        //Print all shapes
        ArrayList<RectangleV4> shapes = new ArrayList<RectangleV4>();

        shapes.add( one );
        shapes.add( two );
        shapes.add( two );
        shapes.add( three );
        shapes.add( four );
        shapes.add( five );

        for(RectangleV4 rect: shapes)
         showEffectBoth(rect);
        System.out.println();
        //Compare all shapes
        
        for(int i = 0; i < shapes.size(); i++)
        {
          if (shapes.get(i).equals(two))
          {
            System.out.print(shapes.get(i) + " IS same size as ");
            System.out.println(shapes.get(2));
          }
          
          else
          {
            System.out.print(shapes.get(i) + " is NOT the same size as ");
            System.out.println(shapes.get(2));
          }
        }
    }
}