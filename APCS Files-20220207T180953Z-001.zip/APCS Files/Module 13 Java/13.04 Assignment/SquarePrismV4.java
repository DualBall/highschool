/**
 * @purpose Defines a Square Prism object by extending the Box object.
 *
 * @author Jack Moran
 * @version 02/05/18
 */
public class SquarePrismV4 extends BoxV4
{
    // instance variables
    private int side1;
    private int side2;

    // Constructor for objects of class Box
    public SquarePrismV4(int s1, int s2)
    {
        // call superclass
        super(s1, s2, s2);

        // initialize instance variables
        side1 = s1;
        side2 = s2;
    }

    // String to display when object is printed.
    public String toString()
    {
      return "Square Prism - " + side1 + " X " + side2 + " X " + side2;
    }
}