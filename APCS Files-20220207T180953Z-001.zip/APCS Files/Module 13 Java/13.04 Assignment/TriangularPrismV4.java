/**
 * @purpose Defines a Square Prism object by extending the Box object.
 *
 * @author Jack Moran
 * @version 02/05/18
 */
public class TriangularPrismV4 extends BoxV4
{
    // instance variables
    private int side1;
    private int side2;
    private int side3;

    // Constructor for objects of class Triangular Prism
    public TriangularPrismV4(int l, int w, int h)
    {
        // call superclass
        super(l, w, h);

        // initialize instance variables
        side1 = l;
        side2 = w;
        side3 = h;
    }

    // String to display when object is printed.
    public String toString()
    {
      return "Triangular Prism - " + side1 + " X " + side2 + " X " + side3;
    }
}