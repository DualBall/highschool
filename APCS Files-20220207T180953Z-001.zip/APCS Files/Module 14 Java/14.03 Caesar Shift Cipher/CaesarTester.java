/**
 * @purpose Runs the ecryption program.
 *
 * @author (Jack Moran)
 * @version (2/14/18)
 */

import java.util.Scanner;

public class CaesarTester
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner (System.in);
        
        //prompts user input for the shift key
        System.out.print("Enter a shift key between 0 and 25: ");
        int key = in.nextInt() * 2;
        System.out.println();

        //ensures input is correct
        while (key < 0 || key > 25)
        {
          System.out.print("Invalid shift key, please try again: ");
          key = in.nextInt();
          System.out.println();
        }
        
        //prompts the selection for encryption and decryption
        System.out.println("Do you want to use this shift key for ");
        System.out.println("encryption or decryption? Type E to select ");
        System.out.print("encryption or D for decryption: ");
        String select = in.next();
        System.out.println();
        
        /*
         * Checks for correct input. This is done outside the loop so the
         * user doesn't accidentally quit.
         */
        while (!select.equalsIgnoreCase("E") && !select.equalsIgnoreCase("D"))
        {
           System.out.print("Invalid selection, please try again: ");
           select = in.next();
           System.out.println();
        }
        
        //uses the user's input to execute accordingly
        while (!select.equalsIgnoreCase("Q"))
        {
           //ensures input is correct
           while (!select.equalsIgnoreCase("E") && !select.equalsIgnoreCase("D"))
           {
              System.out.print("Invalid selection, please try again: ");
              select = in.next();
              System.out.println();
           }
           
           //nests the executions so that the user can switch between them
           while (select.equalsIgnoreCase("E"))
           {
             //prints each alphabet
             System.out.println("You have selected Encryption. Here is your");
             System.out.println("cipher alphabet, compared to the normal aphabet: ");
             System.out.println();
             System.out.println("Regular: " + Encryption.getAlpha());
             System.out.println("Cipher : " + Encryption.getCryptAlpha(key));
             System.out.println();
             System.out.print("Please note that the message can only ");
             System.out.println("include letters and spaces; no symbols.");
             System.out.println("Enter the message you would like to encrypt:");
             String message = in.next();
             message += in.nextLine();
             System.out.println();
             System.out.print("Encrypted message: ");
             System.out.println(Encryption.encryptionBoyz(message.trim(), key));
             System.out.println();
             System.out.println("If you would like to continue encrypting,");
             System.out.println("enter E again. If you would like to switch");
             System.out.println("to decryption, enter D. To quit, enter Q.");
             System.out.println("Note: To change the shift key, you will ");
             System.out.println("have to quit and restart the program.");
             select = in.next();
           }

           while (select.equalsIgnoreCase("D"))
           {
             //prints each alphabet
             System.out.println("You have selected Decryption. Here is your");
             System.out.println("cipher alphabet, compared to the normal aphabet: ");
             System.out.println();
             System.out.println("Regular: " + Encryption.getAlpha());
             System.out.println("Cipher : " + Encryption.getCryptAlpha(key));
             System.out.println();
             System.out.print("Please note that the message can only ");
             System.out.println("include letters and spaces; no symbols.");
             System.out.println("Enter the message you would like to decrypt:");
             String message = in.next();
             message += in.nextLine();
             System.out.print("Decrypted message: ");
             System.out.println(Decryption.decryptionBoyz(message, key));
             System.out.println();
             System.out.println("If you would like to continue decrypting,");
             System.out.println("enter D again. If you would like to switch");
             System.out.println("to encryption, enter E. To quit, enter Q.");
             System.out.println("Note: To change the shift key, you will ");
             System.out.println("have to quit and restart the program.");
             select = in.next();
           }
        }
    }
}