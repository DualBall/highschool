
/**
 * Write a description of class Decryption here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Decryption
{
    public static final String alpha = "A B C D E F G H I J K L M N O P Q R S T" + 
    " U V W X Y Z A B C D E F G H I J K L M N O P Q R S T U V W X Y Z";
    
    /**
     * Retrieves the alphabet.
     *
     * @return The alphabet.
     */
    public static String getAlpha()
    {
       return  alpha.substring(0, 52);
    }
    
    /**
     * Finds and retrieves the cipher alphabet.
     * 
     * @return The cipher alphabet.
     * @param k >= 0 and k <= 25
     */
    public static String getCryptAlpha(int k)
    {
       return alpha.substring(k, 52 + k);
    }
    
    /**
     * Decrypts a message input by the user.
     * 
     * @return The decrypted message.
     */
    public static String decryptionBoyz(String mess, int k)
    {
       String decrypted = "";
       mess.toUpperCase();
       
       /* 
        * Searches for the letter in the alphabet each letter of the message
        * is equal to. Once this is done, the letter will then be shifted
        * backwards and added to the decrypted message.
        */
       for (int i = 0; i < mess.length(); i++)
       {
          for (int index = 0; index < getCryptAlpha(k).trim().length(); index++)
          {
            if (getCryptAlpha(k).trim().substring(index, index + 1).equalsIgnoreCase(mess.substring(i, i + 1)))
            {
              decrypted += getAlpha().trim().substring(index, index + 1);
            }
          }
       }
       
       return decrypted;
    }
}
