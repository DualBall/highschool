
/**
 * @purpose Encrypts a message using a shift key of the user's choosing.
 *
 * @author (Jack Moran)
 * @version (2/14/18)
 */
public class Encryption
{
    public static final String alpha = "A B C D E F G H I J K L M N O P Q R S T" + 
    " U V W X Y Z A B C D E F G H I J K L M N O P Q R S T U V W X Y Z";

    /**
     * Retrieves the alphabet.
     *
     * @return The alphabet.
     */
    public static String getAlpha()
    {
       return  alpha.substring(0, 52);
    }
    
    /**
     * Finds and retrieves the cipher alphabet.
     * 
     * @return The cipher alphabet.
     * @param k >= 0 and k <= 25
     */
    public static String getCryptAlpha(int k)
    {
       return alpha.substring(k, 52 + k);
    }
    
    /**
     * Encrypts a message input by the user.
     * 
     * @return The encrypted message.
     */
    public static String encryptionBoyz(String mess, int k)
    {
       String encrypted = "";
       mess.trim();
       
       /* 
        * Searches for the letter in the alphabet each letter of the message
        * is equal to. Once this is done, the letter will then be shifted
        * and added to the encrypted message.
        */
       for (int i = 0; i < mess.length(); i++)
       {
          for (int index = 0; index < getAlpha().trim().length(); index++)
          {
            if (alpha.trim().substring(index, index + 1).equalsIgnoreCase(mess.substring(i, i + 1)))
            {
              encrypted += getCryptAlpha(k).substring(index, index + 1);
            }
            
            else if (mess.substring(i, i + 1).equals(" "))
              encrypted += " ";
          }
       }
       
       return encrypted;
     }
}
