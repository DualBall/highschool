/**
 * @purpose: Runs the CO2FromWasteV1 program.
 *
 * @author (Jack Moran)
 * @version (11/9/17)
 *
 */
import java.util.ArrayList;

public class ThisCO2FromWasteTesterV1
{
   public static void main(String[] args)
   {
       ThisCO2FromWasteV1 call;
       
       ArrayList<ThisCO2FromWasteV1> households = new ArrayList<ThisCO2FromWasteV1>();
       households.add(new ThisCO2FromWasteV1(4, true, true, true, true));
       households.add(new ThisCO2FromWasteV1(1, false, false, false, false));
       households.add(new ThisCO2FromWasteV1(6, true, false, true, true));
       households.add(new ThisCO2FromWasteV1(2, true, true, true, false));
       households.add(new ThisCO2FromWasteV1(4, false, true, false, true));
       households.add(new ThisCO2FromWasteV1(5, false, true, true, true));

       for(ThisCO2FromWasteV1 dataRecord : households)
       {
           dataRecord.calcGrossWasteEmission();
           dataRecord.calcWasteReduction();
           dataRecord.calcNetWasteReduction();
       }

       System.out.println("|       |        |                                         |             Pounds of CO2             |");
       System.out.println("|       |        |       Household Waste Recycled          |   Total    |             |     Net    |");
       System.out.println("| Index | People |  Paper   |  Plastic |  Glass  |  Cans   |  Emission  |  Reduction  |  Emission  |");
       System.out.println("|-------|--------|----------|----------|---------|---------|------------|-------------|------------|");

       ThisCO2FromWasteV1 dataRecord;

       for(int index = 0; index < households.size(); index ++)
       {
           call = households.get(index);
           System.out.printf("|%4d   |%6d  |   ", index, call.getNumPeople());
           if(call.getPaper())
           System.out.print("true   |  ");
           else
           System.out.print("false  |  ");
           
           if(call.getPlastic())
           System.out.print("true    |  ");
           else
           System.out.print("false   |  ");
           
           if(call.getGlass())
           System.out.print("true   |  ");
           else
           System.out.print("false  |  ");
           
           if(call.getCans())
           System.out.print("true   |");
           else
           System.out.print("false  |");
           
           System.out.printf("%10.2f  |%10.2f   |%11.2f |%n",
           call.getEmissions(), call.getReduction(), call.getNetEmissions());
       }
   }
}
