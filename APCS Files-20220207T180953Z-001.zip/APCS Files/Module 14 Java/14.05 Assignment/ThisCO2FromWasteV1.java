/** @purpose This class calculates the amount of CO2 produced in a year from a
 * household's waste and calculates how much that household's recycling can 
 * reduce the footprint.
 *
 * @author (Jack Moran)
 * @version (11/9/17)
 *
 */
public class ThisCO2FromWasteV1
{
   private int numPeople;
   private boolean paper, plastic, glass, cans;
   private double myEmissions, myReduction, myNetEmissions;

   /**
    * Constructor for objects of type CO2FromWaste
    * @param numPeople number of people in a household
    * @param paper whether or not paper is recycled
    * @param plastic whether or not plastic is recycled
    * @param glass whether or not glass is recycled
    * @param cans whether or not cans are recycled
    */
   ThisCO2FromWasteV1(int numPeople, boolean paper, boolean plastic, boolean glass, boolean cans)
   {
       this.numPeople = numPeople;
       this.paper = paper;
       this.plastic = plastic;
       this.glass = glass;
       this.cans = cans;
   }

   /**
    * Mutator method to calculate the total emissions, without any recycling (no parameters)
    */
   public void calcGrossWasteEmission()
   {
      myEmissions = numPeople * 1018.0;  
   }

   /**
    * Mutator method to calculate the emission reduction from recycling (no parameters)
    */
   public void calcWasteReduction()
   {
       if(paper)
       {
           myReduction += (184.0 * numPeople);
       }

       if(plastic)
       {
           myReduction += (25.6 * numPeople);
       }
       
       if(glass)
       {
           myReduction += (46.6 * numPeople);
       }
       
       if(cans)
       {
           myReduction += (165.8 * numPeople);
       }
   }

   /**
    * Mutator method to calculate the net emissions (no parameters)
    */
   public void calcNetWasteReduction()
   {
        myNetEmissions = myEmissions - myReduction;
   }

   /**
    * Getter method to return the number of people (no parameters)
    */
   public int getNumPeople()
   {
       return numPeople;
   }

   /**
    * Getter method to return paper's recycled status (true or false) (no parameters)
    */
   public boolean getPaper()
   {
       return paper;
   }

   /**
    * Getter method to return glass's recycled status (true or false) (no parameters)
    */
   public boolean getGlass()
   {
       return glass;
   }

   /**
    * Getter method to return plastic's recycled status (true or false) (no parameters)
    */
   public boolean getPlastic()
   {
       return plastic;
   }

   /**
    * Getter method to return cans' recycled status (true or false) (no parameters)
    */
   public boolean getCans()
   {
       return cans;
   }

   /**
    * Getter method to return the total emissions (no parameters)
    */
   public double getEmissions()
   {
       return myEmissions;
   }

   /**
    * Getter method to return the reduction amount (no parameters)
    */
   public double getReduction()
   {
       return myReduction;
   }

   /**
    * Getter method to return the net emissions (no parameters)
    */
   public double getNetEmissions()
   {
       return myNetEmissions;
   }
}
