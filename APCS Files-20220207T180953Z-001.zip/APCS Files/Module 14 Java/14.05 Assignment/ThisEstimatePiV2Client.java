/**
 * @purpose Runs the EstimatePiV2 program 10 times (carries out 10 sets of
 * trials) using values based on user input.
 *
 * @author (Jack Moran)
 * @version (11/10/17)
 */
import java.util.Scanner;
import java.util.ArrayList;
public class ThisEstimatePiV2Client
{
  public static void main (String [] args)
  {
    //sets up the scanner, method call object and variables
    Scanner in = new Scanner(System.in);
    ThisEstimatePiV2 call;
    double piSum = 0.0;
    double currentPi = 0.0;
    
    //sets up the array list
    ArrayList<ThisEstimatePiV2> estimations = new ArrayList<ThisEstimatePiV2>();
    
    //wraps the program in a loop that will repeat 10 times
    for (int index = 0; index < 10; index++)
    {
      //prompts user input
      System.out.print("Enter the amount of darts per trial: ");
      int trialDarts = Integer.parseInt(in.next());
      System.out.println();
      System.out.print("Enter the amount of trials: ");
      int trialNum = Integer.parseInt(in.next());
      System.out.println();
      
      estimations.add(new ThisEstimatePiV2(trialDarts));
      call = estimations.get(index);
    
      //calls methods and prints the results
      for (int i = 1; i <= trialNum; i++)
      {
        currentPi = call.trialSim();
        call.piCalc(currentPi);
        System.out.println(call.toString(i, currentPi));
        piSum += currentPi;
      }
      
      //prints the footer
      System.out.printf("Minimum estimation of pi = %8.6f%n", call.getMin());
      System.out.printf("Maximum estimation of pi = %8.6f%n", call.getMax());
      System.out.printf("Final estimation of pi = %8.6f%n", piSum / trialNum);
      System.out.println();
      }
    }
  }