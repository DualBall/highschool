
/**
 * @purpose Calculates and counts the amount of prime numbers in a given
 * domain.
 *
 * @author (Jack Moran)
 * @version (2/21/18)
 */
public class PrimeSet
{
    private final int min, max;
    
    /**
     * Constructor for objects of class PrimeSet
     */
    public PrimeSet(int min, int max)
    {
       this.min = min;
       this.max = max;
    }

    /**
     * Assembles an array of prime numbers.
     *
     * @return an array containing the prime numbers within the user's
     * limits.
     */
    public int[] numArray(int[] set)
    {
        for (int i = 0; i < set.length; i++)
         set[i] = min + i;
        
        return set;
    }
}
