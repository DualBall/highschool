/**
 * @purpose Runs the PrimeSet program based on user input.
 *
 * @author (Jack Moran)
 * @version (2/21/18)
 */
import java.util.Scanner;
import java.util.ArrayList;

public class PrimeSetClient
{
   public static void main(String[] args)
   {
      Scanner in = new Scanner (System.in);
      
      //prompts user input
      System.out.println("Please enter the lower limit for your number set (no decimals): ");
      int low = in.nextInt();
      System.out.println("Please enter the upper limit for your number set (no decimals): ");
      int high = in.nextInt();
      
      //calculates the number set and completes the array
      int[] numberSet = new int[high - low];
      PrimeSet prime = new PrimeSet(low, high);
      numberSet = prime.numArray(numberSet);
      
      //neatly prints the results
      System.out.println("Here is your set of numbers: ");
      System.out.println();
      
      for(int i = 0; i < numberSet.length; i++)
      {
         System.out.print(numberSet[i] + ", ");
         
         //makes an indent for every 8 numbers
         if(i % 8 == 0 && i != 0)
          System.out.println();
      }
      
      System.out.println();
      System.out.print("There are " + numberSet.length + " numbers in this set.");
   }
}
