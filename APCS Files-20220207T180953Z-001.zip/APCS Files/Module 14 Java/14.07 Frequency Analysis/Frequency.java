
/**
 * @purpose Analyzes the frequency of letters in a file.
 *
 * @author (Jack Moran)
 * @version (2/23/18)
 */
public class Frequency
{
    // instance variables - replace the example below with your own
    private static final String alphabet = "abcdefghijklmnopqrstuvwxyz";

    /**
     * Finds the frequency of every letter in the alphabet based on a
     * provided array.
     *
     * @return the frequency of the letters
     */
    public static int[] freq(String[] tokens)
    {
      int [] instance = new int[alphabet.length()];
      int instances = 0, totalLength = 0;
      
      for (int i = 0; i < tokens.length; i++)
      {
        for (int index = 0; index < alphabet.length(); index++)
        {
          for (int pos = 0; pos < tokens[i].length(); pos++)
          {
             if (tokens[i].substring(pos, pos + 1).equals(alphabet.substring(index, index + 1)))
              instances++;
          }
          
          instance[index] += instances;
          instances = 0;
        }
        
        totalLength += tokens[i].length();
      }
      
      return instance;
    }
    
    /**
     * An alternate version of freq that returns percentage instead of
     * numbers
     *
     * @return the percentage frequency of the letters
     */
    public static String[] freqPer(String[] tokens)
    {
      int [] instance = new int[alphabet.length()];
      int instances = 0, totalLength = 0;
      String [] results = new String[alphabet.length()];
      
      for (int i = 0; i < tokens.length; i++)
      {
        for (int index = 0; index < alphabet.length(); index++)
        {
          for (int pos = 0; pos < tokens[i].length(); pos++)
          {
            if (tokens[i].substring(pos, pos + 1).equals(alphabet.substring(index, index + 1)))
              instances++;
          }
          
          instance[index] += instances;
          instances = 0;
        }
        
        totalLength += tokens[i].length();
      }
      
      for (int i = 0; i < results.length; i++)
       results[i] = (int)(((double)instance[i] / totalLength) * 100) + "%";
      
      return results;
    }
}
