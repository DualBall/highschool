
/**
 * @purpose Runs the Frequency program based on user input.
 *
 * @author (Jack Moran)
 * @version (2/23/18)
 */
import java.util.Scanner;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.File;

public class FrequencyClient
{
  public static void main(String[] args) throws IOException
  {
    //sets up variables
    Scanner in = new Scanner(System.in);
    int fileLength = 0;
    String tempToken = "";
    String alphabet = "abcdefghijklmnopqrstuvwxyz";
    
    //prompts user input
    System.out.println("Please enter the name of your input file: ");
    String name = in.next() + ".txt";
    File file = new File(name);
    Scanner inFile = new Scanner (file);
    
    //determines how many words are in the file
    while (inFile.hasNext())
    {
      tempToken = inFile.next();
      fileLength++;
    }
    inFile.close();
    inFile = new Scanner (file);
    
    //creates an array to run Frequency based on how many words there are
    String[] tokens = new String[fileLength];
    for (int i = 0; i < tokens.length; i++)
     tokens[i] = inFile.next().toLowerCase();
    inFile.close();
    int[] results = Frequency.freq(tokens);
    String[] resultsPer = Frequency.freqPer(tokens);
    
    //prints the results
    System.out.println("               Results");
    System.out.println("-------------------------------------");
    System.out.println("Letter      Occurences      Frequency");
    
    for (int i = 0; i < results.length; i++)
    {
      System.out.printf("%4s\t\t%3d\t\t%5s\n", alphabet.substring(i, i+1),
      results[i], resultsPer[i]);
    }
    
    //prints the results to a file
    name = name.replace(".txt", "Freq.txt");
    PrintWriter outFile = new PrintWriter(new File(name));
    
    for (int i = 0; i < results.length; i++)
    {
      outFile.println(alphabet.substring(i, i+1) + "   " + results[i] + "    " + resultsPer[i]);
    }
    outFile.close();
  }
}