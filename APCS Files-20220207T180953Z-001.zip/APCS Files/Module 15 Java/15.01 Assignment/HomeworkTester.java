
/**
 * Creates homework assignments for various courses.
 *
 * @author (Jack Moran)
 * @version (3/11/18)
 */
import java.util.ArrayList;

public class HomeworkTester
{
  public static void main(String []args)
  {
    //constructs objects for each subject
    ArrayList<Homework> types = new ArrayList<Homework>();
    
    types.add(new Trigonometry());
    types.add(new Spanish());
    types.add(new WorldHistory());
    types.add(new APEconomics());
    
    //sets page numbers for each subject
    int trigPages = 4, spanishPages = 2, historyPages = 5, economyPages = 7;
    
    //prints the results
    types.get(0).assignment(trigPages);
    types.get(1).assignment(spanishPages);
    types.get(2).assignment(historyPages);
    types.get(3).assignment(economyPages);
    
    System.out.println("--- Homework To-Do List ---");
    System.out.println(types.get(0));
    System.out.println(types.get(1));
    System.out.println(types.get(2));
    System.out.println(types.get(3));
  }
}
