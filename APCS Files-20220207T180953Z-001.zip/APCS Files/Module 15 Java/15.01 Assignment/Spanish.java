
/**
 * @purpose Creates homework assignments for Spanish.
 *
 * @author (Jack Moran)
 * @version (3/11/18)
 */
public class Spanish extends Homework
{
    /**
     * Constructor for objects of class Spanish
     */
    public Spanish()
    {
      super();
    }

    public void assignment(int pages)
    {
      setPageNum(pages);
      setSubject("Spanish");
    }
    
    public String toString()
    {
      return getSubject() + " - read " + getPageNum() + " pages.";
    }
}
