
/**
 * @purpose Creates homework assignments for Trigonometry.
 *
 * @author (Jack Moran)
 * @version (3/11/18)
 */
public class Trigonometry extends Homework
{
    /**
     * Constructor for objects of class Trigonometry
     */
    public Trigonometry()
    {
      super();
    }

    /**
     * Creates a Trigonometry assignment.
     *
     * @param  pages The number of pages to read.
     */
    public void assignment(int pages)
    {
      setPageNum(pages);
      setSubject("Trigonometry");
    }
    
    public String toString()
    {
      return getSubject() + " - read " + getPageNum() + " pages.";
    }
}
