
/**
 * @purpose Creates homework assignments for World History.
 *
 * @author (Jack Moran)
 * @version (3/11/18)
 */
public class WorldHistory extends Homework
{
    /**
     * Constructor for objects of class WorldHistory
     */
    public WorldHistory()
    {
      super();
    }

    public void assignment(int pages)
    {
      setPageNum(pages);
      setSubject("World History");
    }
    
    public String toString()
    {
      return getSubject() + " - read " + getPageNum() + " pages.";
    }
}
