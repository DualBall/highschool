
/**
 * Creates homework assignments for various courses.
 *
 * @author (Jack Moran)
 * @version (3/11/18)
 */
import java.util.*;

public class HomeworkTesterV3
{
  public static void main(String []args)
  {
    //constructs objects for each subject
    List<HomeworkV3> types = new ArrayList<HomeworkV3>();
    
    types.add(new TrigonometryV3());
    types.add(new SpanishV3());
    types.add(new WorldHistoryV3());
    types.add(new APEconomicsV3());
    
    //sets page numbers for each subject
    int trigPages = 4, spanishPages = 2, historyPages = 5, economyPages = 7;
    
    //runs methods as necessary
    types.get(0).assignment(trigPages);
    types.get(1).assignment(spanishPages);
    types.get(2).assignment(historyPages);
    types.get(3).assignment(economyPages);
    
    System.out.println("--- My Homework ---");
    
    for (HomeworkV3 h : types)
    {
      System.out.println("Before reading: " + h);
      h.readSome(2);
      System.out.println("After reading: " + h);
      System.out.println();
    }
  }
}
