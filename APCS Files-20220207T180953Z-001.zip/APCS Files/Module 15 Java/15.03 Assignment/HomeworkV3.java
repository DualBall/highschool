
/**
 * @purpose Serves as an abstract superclass to various types of 
 * homework.
 *
 * @author (Jack Moran)
 * @version (3/11/18)
 */
public abstract class HomeworkV3 implements Processing
{
    // instance variables
    private int pageNum;
    private String subject;
    
    // Constructor for the abstract class Homework
    public HomeworkV3()
    {
      pageNum = 0;
      subject = "none";
    }

    //sets up the assignment class for subclasses
    public abstract void assignment(int pages);
    
    public int getPageNum()
    {
       return pageNum;
    }

    public void setPageNum(int pageNum)
    {
       this.pageNum = pageNum;
    }
    
    public String getSubject()
    {
       return subject;
    }
    
    public void setSubject(String subject)
    {
       this.subject = subject;
    }
}
