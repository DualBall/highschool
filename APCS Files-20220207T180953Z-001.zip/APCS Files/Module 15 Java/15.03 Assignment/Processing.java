
 /**
 * @purpose A simple interface for doing homework.
 *
 * @author (Jack Moran)
 * @version (03/12/18)
 */

public interface Processing
{
    void readSome(int pages);
}
