
/**
 * @purpose Creates homework assignments for World History.
 *
 * @author (Jack Moran)
 * @version (3/11/18)
 */
public class APEconomicsV4 extends HomeworkV4
{
    /**
     * Constructor for objects of class APEconomics
     */
    public APEconomicsV4()
    {
      super();
    }

    public void assignment(int pages)
    {
      setPageNum(pages);
      setSubject("AP Economics");
    }
    
    /**
     * Completes part of the homework assignment.
     * 
     * @param pages The number of pages read.
     */
    public void readSome(int pages)
    {
      setPageNum(getPageNum() - pages);
    }
    
    public String toString()
    {
      return getSubject() + " - " + getPageNum() + " pages to read.";
    }
}
