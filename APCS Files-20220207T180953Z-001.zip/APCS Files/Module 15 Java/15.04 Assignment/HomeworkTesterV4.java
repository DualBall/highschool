
/**
 * Creates homework assignments for various courses.
 *
 * @author (Jack Moran)
 * @version (3/11/18)
 */
import java.util.*;

public class HomeworkTesterV4
{
  public static void main(String []args)
  {
    //constructs objects for each subject
    List<HomeworkV4> types = new ArrayList<HomeworkV4>();
    
    types.add(new TrigonometryV4());
    types.add(new SpanishV4());
    types.add(new WorldHistoryV4());
    types.add(new APEconomicsV4());
    
    //sets page numbers for each subject
    int trigPages = 4, spanishPages = 2, historyPages = 5, economyPages = 7;
    
    //runs methods as necessary
    types.get(0).assignment(trigPages);
    types.get(1).assignment(spanishPages);
    types.get(2).assignment(historyPages);
    types.get(3).assignment(economyPages);
    
    System.out.println("--- My Homework ---");
    
    for (HomeworkV4 h : types)
    {
      System.out.println("Before reading: " + h);
      h.readSome(2);
      System.out.println("After reading: " + h);
      System.out.println();
    }
    
    if(types.get(0).compareTo(types.get(1)) == -1)
    {
      System.out.print("The homework for " + types.get(0).getSubject());
      System.out.println(" has LESS pages to read than " + types.get(1).getSubject());
    }
    else if(types.get(0).compareTo(types.get(1)) == 1)
    {
      System.out.print("The homework for " + types.get(0).getSubject());
      System.out.println(" has MORE pages to read than " + types.get(1).getSubject());
    }
    else
    {
      System.out.print("The homework for " + types.get(0).getSubject());
      System.out.println(" and " + types.get(1).getSubject() + "are the SAME number of pages");
    }
    
    if(types.get(0).compareTo(types.get(2)) == -1)
    {
      System.out.print("The homework for " + types.get(0).getSubject());
      System.out.println(" has LESS pages to read than " + types.get(2).getSubject());
    }
    else if(types.get(0).compareTo(types.get(2)) == 1)
    {
      System.out.print("The homework for " + types.get(0).getSubject());
      System.out.println(" has MORE pages to read than " + types.get(2).getSubject());
    }
    else
    {
      System.out.print("The homework for " + types.get(0).getSubject());
      System.out.println(" and " + types.get(2).getSubject() + "are the SAME number of pages");
    }
    
    if(types.get(0).compareTo(types.get(3)) == -1)
    {
      System.out.print("The homework for " + types.get(0).getSubject());
      System.out.println(" has LESS pages to read than " + types.get(3).getSubject());
    }
    else if(types.get(0).compareTo(types.get(1)) == 1)
    {
      System.out.print("The homework for " + types.get(0).getSubject());
      System.out.println(" has MORE pages to read than " + types.get(3).getSubject());
    }
    else
    {
      System.out.print("The homework for " + types.get(0).getSubject());
      System.out.println(" and " + types.get(3).getSubject() + "are the SAME number of pages");
    }
    
    if(types.get(1).compareTo(types.get(2)) == -1)
    {
      System.out.print("The homework for " + types.get(1).getSubject());
      System.out.println(" has LESS pages to read than " + types.get(2).getSubject());
    }
    else if(types.get(1).compareTo(types.get(2)) == 1)
    {
      System.out.print("The homework for " + types.get(1).getSubject());
      System.out.println(" has MORE pages to read than " + types.get(2).getSubject());
    }
    else
    {
      System.out.print("The homework for " + types.get(1).getSubject());
      System.out.println(" and " + types.get(2).getSubject() + "are the SAME number of pages");
    }
    
    if(types.get(1).compareTo(types.get(3)) == -1)
    {
      System.out.print("The homework for " + types.get(1).getSubject());
      System.out.println(" has LESS pages to read than " + types.get(3).getSubject());
    }
    else if(types.get(1).compareTo(types.get(3)) == 1)
    {
      System.out.print("The homework for " + types.get(1).getSubject());
      System.out.println(" has MORE pages to read than " + types.get(3).getSubject());
    }
    else
    {
      System.out.print("The homework for " + types.get(1).getSubject());
      System.out.println(" and " + types.get(3).getSubject() + "are the SAME number of pages");
    }
    
    if(types.get(2).compareTo(types.get(3)) == -1)
    {
      System.out.print("The homework for " + types.get(2).getSubject());
      System.out.println(" has LESS pages to read than " + types.get(3).getSubject());
    }
    else if(types.get(0).compareTo(types.get(1)) == 1)
    {
      System.out.print("The homework for " + types.get(2).getSubject());
      System.out.println(" has MORE pages to read than " + types.get(3).getSubject());
    }
    else
    {
      System.out.print("The homework for " + types.get(2).getSubject());
      System.out.println(" and " + types.get(3).getSubject() + "are the SAME number of pages");
    }
    
    
  }
}
