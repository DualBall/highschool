
/**
 * @purpose A simple interface for doing homework.
 *
 * @author (Jack Moran)
 * @version (03/12/18)
 */

public interface ProcessingV4
{
    void readSome(int pages);
}
