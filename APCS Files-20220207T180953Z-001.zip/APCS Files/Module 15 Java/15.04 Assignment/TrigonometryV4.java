
/**
 * @purpose Creates homework assignments for Trigonometry.
 *
 * @author (Jack Moran)
 * @version (3/11/18)
 */
public class TrigonometryV4 extends HomeworkV4
{
    /**
     * Constructor for objects of class Trigonometry
     */
    public TrigonometryV4()
    {
      super();
    }

    /**
     * Creates a Trigonometry assignment.
     *
     * @param  pages The number of pages to read.
     */
    public void assignment(int pages)
    {
      setPageNum(pages);
      setSubject("Trigonometry");
    }
    
    /**
     * Completes part of the homework assignment.
     * 
     * @param pages The number of pages read.
     */
    public void readSome(int pages)
    {
      setPageNum(getPageNum() - pages);
    }
    
    public String toString()
    {
      return getSubject() + " - " + getPageNum() + " pages to read.";
    }
    
    
}
