
/**
 * @purpose A class embodying the game Antihero.
 *
 * @author (Jack Moran)
 * @version (3/21/18)
 */
public class Antihero extends VideoGame
{
    /**
     * Constructor for objects of class Antihero
     */
    public Antihero()
    {
        super("Antihero", 5);
    }
    
    /**
     * Raises the base cost based on which platform the game is on
     *
     * @param p A name of the platform
     */
    public void platform(String p)
    {
      if (p.equals("pc"))
       setCost(15);
    }
}
