
/**
 * @purpose A class embodying a Drone.
 *
 * @author (Jack Moran)
 * @version (3/21/18)
 */
public class Drone extends RCToys
{
    /**
     * Constructor for objects of class Drone
     */
    public Drone()
    {
      super("Drone", 20);
    }

    /**
     * Raises the based cost based on which brand is selling the drone
     *
     * @param b A letter a or b that determines which brand it is
     */
    public void brand(String b)
    {
      if (b.equals("a"))
       setCost(25);
      else
       setCost(30);
    }
}
