
/**
 * An interface for various Product classes.
 *
 * @author (Jack Moran)
 * @version (3/21/18)
 */
public interface Product
{
  String getName();
  int getCost();
}
