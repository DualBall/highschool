
/**
 * Creates and compares different products.
 *
 * @author (Jack Moran)
 * @version (3/21/18)
 */
import java.util.*;

public class ProductTester
{
  public static void inventory(String name, List<RCToys> list1, List<VideoGame> list2)
  {
    int quantity = 0, cost = 0;
    
    for (RCToys l : list1)
    {
      if (name.equals(l.getName()))
        {
          quantity ++;
          cost = l.getCost();
        }
    }
    
    for (VideoGame l : list2)
    {
      if (name.equals(l.getName()))
        {
          quantity ++;
          cost = l.getCost();
        }
    }
    
    System.out.print(name + ": Quantity = " + quantity + ", Total Cost = $");
    System.out.println(cost * quantity);
  }
    
  public static void main(String[] args)
  {
    int q = 0;
    //constructs the products
    List<RCToys> rcProducts = new ArrayList<RCToys>();
    List<VideoGame> gameProducts = new ArrayList<VideoGame>();
    
    rcProducts.add(new RCCar());
    rcProducts.add(new RCCar());
    rcProducts.add(new Drone());
    rcProducts.add(new Drone());
    rcProducts.add(new Drone());
    gameProducts.add(new RainbowSix());
    gameProducts.add(new Antihero());
    
    //runs methods as necessary
    for (RCToys rc : rcProducts)
     rc.brand("b");
    rcProducts.get(0).brand("a");
    rcProducts.get(2).brand("a");
    gameProducts.get(0).platform("pc");
    
    //prints the results
    System.out.println("--- Inventory ---");
    inventory("RC Car", rcProducts, gameProducts);
    inventory("Drone", rcProducts, gameProducts);
    inventory("Rainbow Six Siege", rcProducts, gameProducts);
    inventory("Antihero", rcProducts, gameProducts);
    System.out.println();
    System.out.println();
    System.out.println("--- Comparing Games ---");
    
    if(gameProducts.get(0).compareTo(gameProducts.get(1)) == -1)
    {
      System.out.print(gameProducts.get(0).getName() + " is cheaper than ");
      System.out.println(gameProducts.get(1).getName());
    }
    else if(gameProducts.get(0).compareTo(gameProducts.get(1)) == 0)
    {
      System.out.print(gameProducts.get(0).getName() + " is the same ");
      System.out.println("price as " + gameProducts.get(1).getName());
    }
    else
    {
      System.out.print(gameProducts.get(0).getName() + " is more expensive ");
      System.out.println("than " + gameProducts.get(1).getName());
    }
  }
}
