
/**
 * @purpose A class embodying an RC car.
 *
 * @author (Jack Moran)
 * @version (3/21/18)
 */
public class RCCar extends RCToys
{
    /**
     * Constructor for objects of class RCCar
     */
    public RCCar()
    {
      super("RC Car", 12);
    }

    /**
     * Raises the base cost based on which brand is selling the car
     *
     * @param b A letter a or b that determines which brand it is
     */
    public void brand(String b)
    {
      if (b.equals("a"))
       setCost(15);
      else
       setCost(17);
    }
}
