
/**
 * @purpose Serves as an abstract superclass to various types of RC Toys.
 *
 * @author (Jack Moran)
 * @version (3/21/18)
 */
public abstract class RCToys implements Product
{
    private String name;
    private int cost;
    
    public RCToys(String name, int cost)
    {
      this.name = name;
      this.cost = cost;
    }
    
    public String getName()
    {
      return name;
    }
    
    public int getCost()
    {
      return cost;
    }
    
    public void setCost(int cost)
    {
      this.cost = cost;
    }

    //sets up the brand class for subclasses
    public abstract void brand(String b);
}
