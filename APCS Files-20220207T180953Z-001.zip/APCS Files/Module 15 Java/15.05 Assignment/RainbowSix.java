
/**
 * @purpose A class embodying the game Rainbow Six Siege.
 *
 * @author (Jack Moran)
 * @version (3/21/18)
 */
public class RainbowSix extends VideoGame
{
    /**
     * Constructor for objects of class RainbowSix
     */
    public RainbowSix()
    {
      super("Rainbow Six Siege", 60);
    }

    /**
     * Raises the base cost based on which platform the game is on
     *
     * @param p A name of the platform
     */
    public void platform(String p)
    {
      if (p.equals("pc"))
       setCost(40);
    }
}
