
/**
 * @purpose Serves as an abstract superclass to various types of video games.
 *
 * @author (Jack Moran)
 * @version (3/21/18)
 */
public abstract class VideoGame implements Product, Comparable<VideoGame>
{
    private String name;
    private int cost;

    /**
     * Constructor for objects of class VideoGame
     */
    public VideoGame(String name, int cost)
    {
      this.name = name;
      this.cost = cost;
    }
    
    public String getName()
    {
      return name;
    }
    
    public int getCost()
    {
      return cost;
    }
    
    public void setCost(int cost)
    {
      this.cost = cost;
    }

    //sets up the type class for subclasses
    public abstract void platform(String p);
        
    /**
     * Compares the costs of two games
     */
    public int compareTo(VideoGame obj)
    {
       if (cost < obj.cost)
        return -1;
       else if (cost == obj.cost)
        return 0;
       else
        return 1;
    }
}
