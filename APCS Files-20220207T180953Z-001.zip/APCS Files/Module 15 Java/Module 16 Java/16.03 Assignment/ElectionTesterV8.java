
/**
 * @purpose Tests the Candidate class using an ArrayList.
 *
 * @author (Jack Moran)
 * @version (4/11/18)
 */

import java.util.*;
public class ElectionTesterV8
{
  //prints the candidates and their votes
  public static void arrPrinter (List<Candidate> candidates)
  {
    for (Candidate cand : candidates)
     System.out.println(cand);
  }
  
  //calculates the sum of all votes
  public static int voteTotal (List<Candidate> candidates)
  {
    int sum = 0;
    for (Candidate cand : candidates)
     sum += cand.getVotes();
     
    return sum;
  }
  
  //prints the data
  public static void printResults (List<Candidate> candidates)
  {
    double total = voteTotal(candidates);
    int printTotal = voteTotal(candidates);
      
    for (Candidate cand : candidates)
    {
      System.out.printf("%s\t%9d\t%7.2f\n", cand.getName(),
      cand.getVotes(), cand.getVotes() / total);
    }
    
    System.out.println();
    System.out.println("Total number of votes cast in election: " + printTotal);
  }
  
  public static void rename (List<Candidate> candidates, String name, String newName)
  {
    for (Candidate cand : candidates)
    {
      if (cand.getName().equals(name))
       cand.setName(newName);
    }
  }
  
  public static void voteChange (List<Candidate> candidates, String name, int newVotes)
  {
    for (Candidate cand : candidates)
    {
      if (cand.getName().equals(name))
       cand.setVotes(newVotes);
    }
  }
  
  public static void doubleChange (List<Candidate> candidates, String name, String newName, int newVotes)
  {
    for (Candidate cand : candidates)
    {
      if (cand.getName().equals(name))
      {
        cand.setName(newName);
        cand.setVotes(newVotes);
      }
    }
  }
  
  public static void insert (List<Candidate> candidates, int pos, String name, int votes)
  {   
    candidates.add(pos, new Candidate(name, votes));
  }
  
  public static void insertBefore (List<Candidate> candidates, String nameFind, String name, int votes)
  {   
    for (int i = candidates.size() - 1; i >= 0; i--)
    {  
      if (candidates.get(i).getName().equals(nameFind))
        candidates.add(i - 1, new Candidate(name, votes));
    }
  }
  
  public static void delete (List<Candidate> candidates, int pos)
  {
    candidates.remove(pos);
  }
  
  public static void deleteName (List<Candidate> candidates, String name)
  {
    int index = 0;
      
    for (int i = candidates.size() - 1; i >= 0; i--)
    {  
      if(candidates.get(i).getName().equals(name))
       index = i;
    }
    
    candidates.remove(index);
  }
    
  public static void main (String[] args)
  {
    //creates the candidates
    List<Candidate> cand = new ArrayList<Candidate>();
    cand.add(new Candidate("Lucky Luciano", 6000));
    cand.add(new Candidate("Patrick Star", 3000));
    cand.add(new Candidate("Lil Broomstick", 5000));
    cand.add(new Candidate("Yodeling Kid", 2500));
    cand.add(new Candidate("Sans Undertale", 0));
    
    //prints the raw election data
    System.out.println("Raw Election Data:");
    System.out.println();
    arrPrinter(cand);
    System.out.println();
    
    //prints the original election results
    printResults(cand);
    
    //calls the new methods and prints new results afterwards
    System.out.println("<< Changing Lil Broomstick to Major Clout >>");
    rename(cand, "Lil Broomstick", "Major Clout");
    printResults(cand);
    
    System.out.println("<< Changing Patrick Star's votes to 4000 >>");
    voteChange(cand, "Patrick Star", 4000);
    printResults(cand);
    
    System.out.println("<< Changing Sans Undertale to Waaah luigi >>");
    doubleChange(cand, "Sans Undertale", "Waaah luigi", 7000);
    printResults(cand);
    
    System.out.println("<< In position 0, add Mark Zuckerberg, 01010 votes >>");
    insert(cand, 0, "Mark Zuckerberg", 1010);
    printResults(cand);
    
    System.out.println("<< Before Yodeling Kid, add Illusion 100, 100 votes >>");
    insertBefore(cand, "Yodeling Kid", "Illusion 100", 100);
    printResults(cand);
    
    System.out.println("<< Delete position 1 >>");
    delete(cand, 1);
    printResults(cand);
    
    System.out.println("<< Delete Patrick Star >>");
    deleteName(cand, "Patrick Star");
    printResults(cand);
  }
}