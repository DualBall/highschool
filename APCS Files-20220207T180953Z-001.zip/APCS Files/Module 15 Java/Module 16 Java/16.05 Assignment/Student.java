
/**
 * An object representing a student with 5 quiz scores.
 *
 * @author (Jack Moran)
 * @version (4/16/18)
 */
public class Student
{
    private int Q1, Q2, Q3, Q4, Q5;
    private String name;

    /**
     * Constructor for objects of class Student
     */
    public Student(String name, int Q1, int Q2, int Q3, int Q4, int Q5)
    {
      this.name = name;
      this.Q1 = Q1;
      this.Q2 = Q2;
      this.Q3 = Q3;
      this.Q4 = Q4;
      this.Q5 = Q5;
    }

    public int getValue(int num)
    {
      if (num == 1)
       return Q1;
      else if (num == 2)
       return Q2;
      else if (num == 3)
       return Q3;
      else if (num == 4)
       return Q4;
      else
       return Q5;
    }
    
    public void setValue(int num, int score)
    {
      if (num == 1)
       Q1 = score;
      else if (num == 2)
       Q2 = score;
      else if (num == 3)
       Q3 = score;
      else if (num == 4)
       Q4 = score;
      else
       Q5 = score;
    }
    
    public String getName()
    {
      return name;
    }
    
    public void setName(String name)
    {
      this.name = name;
    }
    
    public String toString()
    {
      return String.format("%-17s%d      %d      %d      %d      %d", name, Q1, Q2, Q3, Q4, Q5);     
    }
}
