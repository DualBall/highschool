
/**
 * @purpose Tests the Student class using an ArrayList.
 *
 * @author (Jack Moran)
 * @version (4/16/18)
 */

import java.util.*;
public class StudentTester
{
  //prints the students and their scores
  public static void arrPrinter (List<Student> students)
  {
    System.out.println();
    System.out.println("Student name     Q1      Q2      Q3      Q4      Q5");
    System.out.println("-----------------------------------------------------");
    for (Student stud : students)
     System.out.println(stud);
    System.out.println();
  }
  
  //renames a student with a certain name
  public static void rename (List<Student> students, String name, String newName)
  {
    for (Student stud : students)
    {
      if (stud.getName().equals(name))
       stud.setName(newName);
    }
  }
  
  //sets a new quiz score for a student with a certain name
  public static void scoreChange (List<Student> students, String name, int num, int newScore)
  {
    for (Student stud : students)
    {
      if (stud.getName().equals(name))
       stud.setValue(num, newScore);
    }
  }
  
  //replaces one student with another
  public static void replace (List<Student> students, String name, String newName, int[] scores)
  {
    rename(students, name, newName);
    
    for (int i = 0; i < scores.length; i++)
      scoreChange(students, name, i, scores[i]);
  }
  
  //inserts a new student before the specified existing student
  public static void insertBefore (List<Student> students, String name, String newName, int[] scores)
  {   
    for (int i = students.size() - 1; i >= 0; i--)
    {  
      if (students.get(i).getName().equals(name))
        students.add(i - 1, new Student(newName, scores[0], scores[1], scores[2], scores[3], scores[4]));
    }
  }
  
  //deletes a student
  public static void delete (List<Student> students, String name)
  {
    for (int i = 0; i < students.size(); i++)
    {  
      if(students.get(i).getName().equals(name))
       students.remove(i);
    }
  }
  
  public static void main (String[] args)
  {
    //creates the students
    List<Student> stud = new ArrayList<Student>();
    stud.add(new Student("Lucky Luciano", 70, 80, 90, 80, 90));
    stud.add(new Student("Patrick Star", 80, 85, 90, 85, 80));
    stud.add(new Student("Waluigi", 50, 79, 89, 99, 99));
    stud.add(new Student("Yodeling Kid", 85, 80, 85, 88, 89));
    stud.add(new Student("Sans Undertale", 70, 70, 90, 70, 80));
    
    //prints the original results
    System.out.println("Starting Gradebook:");
    arrPrinter(stud);
    
    //calls the methods and prints new results afterwards
    System.out.println("<< Changing Patrick Star to Squidward >>");
    rename(stud, "Patrick Star", "Squidward");
    arrPrinter(stud);
    
    System.out.println("<< Changing Lucky Luciano's 70 to 100 >>");
    scoreChange(stud, "Lucky Luciano", 70, 100);
    arrPrinter(stud);
    
    System.out.println("<< Replacing Yodeling Kid with Gru >>");
    int [] gruScores = {50, 90, 70, 60, 80};
    replace(stud, "Yodeling Kid", "Gru", gruScores);
    arrPrinter(stud);
    
    System.out.println("<< Inserting Drake before Squidward >>");
    int [] drakeScores = {90, 40, 70, 65, 100};
    insertBefore(stud, "Squidward", "Drake", drakeScores);
    arrPrinter(stud);
    
    System.out.println("<< Deleting Sans Undertale >>");
    delete(stud, "Sans Undertale");
    arrPrinter(stud);
  }
}
