
/**
 * Purpose: Creates an array of movie objects and sorts them.
 *
 * @author (Jack Moran)
 * @version (4/26/18)
 */
public class MovieTesterV2
{
  public static void arrPrinter(MovieV2[] films)
  {
    for (MovieV2 film : films)
     System.out.println(film);
  }
  
  public static MovieV2[] insertionTitle(MovieV2[] source, int which)
  {
    MovieV2[] dest = new MovieV2[source.length];

    if (which == 1)
    {
     for( int i = 0 ; i < source.length ; i++ )
     {
       MovieV2 next = source[i];
       int insertIndex = 0;
       int k = i;
            
       while( k > 0 && insertIndex == 0 )
       {
         if(next.getTitle().compareTo(dest[k-1].getTitle()) > 0)
         {
           insertIndex = k;
         }
         else
         {
           dest[ k ] = dest[ k - 1 ];
         }
        
         k--;
       }

       dest[insertIndex] = next;
            
       //Debugging Statements 
       //uncomment to print the listings after each pass through the sort
       //System.out.println("\nPass # " + i);
       //for(MovieV2 h : dest)
       //{
       //  if( h != null) 
       //   System.out.printf("%-15s \n", h.getTitle() );
       //}
     }
    }
    
    else if (which == 2)
    {
      for( int i = 0 ; i < source.length ; i++ )
      {
       MovieV2 next = source[i];
       int insertIndex = 0;
       int k = i;
            
       while( k > 0 && insertIndex == 0 )
       {
         if(next.getTitle().compareTo(dest[k-1].getTitle()) < 0)
         {
           insertIndex = k;
         }
         else
         {
           dest[ k ] = dest[ k - 1 ];
         }
        
         k--;
       }

       dest[insertIndex] = next;
            
       //Debugging Statements 
       //uncomment to print the listings after each pass through the sort
       //System.out.println("\nPass # " + i);
       //for(MovieV2 h : dest)
       //{
       //  if( h != null) 
       //   System.out.printf("%-15s \n", h.getTitle() );
       //}
      }
    }
    return dest;
  }
  
  public static MovieV2[] insertionYear(MovieV2[] source, int which)
  {
    MovieV2[] dest = new MovieV2[source.length];
    if (which == 1)
    {
     for( int i = 0 ; i < source.length ; i++ )
     {
       MovieV2 next = source[i];
       int insertIndex = 0;
       int k = i;
            
       while( k > 0 && insertIndex == 0 )
       {
         if(next.getYear() > (dest[k-1].getYear()))
         {
           insertIndex = k;
         }
         else
         {
          dest[ k ] = dest[ k - 1 ];
         }
         
         k--;
       }

       dest[insertIndex] = next;
            
       //Debugging Statements 
       //uncomment to print the listings after each pass through the sort
       //System.out.println("\nPass # " + i);
       //for(MovieV2 h : dest)  
       //{
       //  if( h != null) 
       //   System.out.printf("%4d \n", h.getYear() );
       //}
     }
    }
    else if (which == 2)
    {
      for( int i = 0 ; i < source.length ; i++ )
      {
       MovieV2 next = source[i];
       int insertIndex = 0;
       int k = i;
            
       while( k > 0 && insertIndex == 0 )
       {
         if(next.getYear() < (dest[k-1].getYear()))
         {
           insertIndex = k;
         }
         else
         {
          dest[ k ] = dest[ k - 1 ];
         }
         
         k--;
       }

       dest[insertIndex] = next;
            
       //Debugging Statements 
       //uncomment to print the listings after each pass through the sort
       //System.out.println("\nPass # " + i);
       //for(MovieV2 h : dest)  
       //{
       //  if( h != null) 
       //   System.out.printf("%4d \n", h.getYear() );
       //}
      }
    }
    return dest;
  }
  
  public static MovieV2[] insertionStudio(MovieV2[] source, int which)
  {
    MovieV2[] dest = new MovieV2[source.length];

    if (which == 1)
    {
     for( int i = 0 ; i < source.length ; i++ )
     {
       MovieV2 next = source[i];
       int insertIndex = 0;
       int k = i;
            
       while( k > 0 && insertIndex == 0 )
       {
         if(next.getStudio().compareTo(dest[k-1].getStudio()) > 0)
         {
           insertIndex = k;
         }
         else
         {
           dest[ k ] = dest[ k - 1 ];
         }
        
         k--;
       }

       dest[insertIndex] = next;
            
       //Debugging Statements 
       //uncomment to print the listings after each pass through the sort
       //System.out.println("\nPass # " + i);
       //for(MovieV2 h : dest)
       //{
       //  if( h != null) 
       //   System.out.printf("%-15s \n", h.getStudio() );
       //}
     }
    }
    
    else if (which == 2)
    {
      for( int i = 0 ; i < source.length ; i++ )
      {
       MovieV2 next = source[i];
       int insertIndex = 0;
       int k = i;
            
       while( k > 0 && insertIndex == 0 )
       {
         if(next.getStudio().compareTo(dest[k-1].getStudio()) < 0)
         {
           insertIndex = k;
         }
         else
         {
           dest[ k ] = dest[ k - 1 ];
         }
        
         k--;
       }

       dest[insertIndex] = next;
            
       //Debugging Statements 
       //uncomment to print the listings after each pass through the sort
       //System.out.println("\nPass # " + i);
       //for(MovieV2 h : dest)
       //{
       //  if( h != null) 
       //   System.out.printf("%-15s \n", h.getStudio() );
       //}
      }
    }
    
    return dest;
  }
  
  public static void main(String[] args)
  {
      MovieV2[] films = new MovieV2[10];

      films[0] = new MovieV2("Inside Out", 2016, "Pixar");
      films[1] = new MovieV2("Coco", 2017, "Pixar");
      films[2] = new MovieV2("Wreck-It Ralph", 2012, "Disney");
      films[3] = new MovieV2("Wizard of Oz", 1939, "MGM");
      films[4] = new MovieV2("Moana", 2016, "Disney");
      films[5] = new MovieV2("Hotel Transylvania", 2012, "Sony Pictures Animation");
      films[6] = new MovieV2("Shrek", 2001, "Dreamworks");
      films[7] = new MovieV2("The Emoji Movie", 2017, "Sony Pictures Animation");
      films[8] = new MovieV2("WALL-E", 2008, "Pixar");
      films[9] = new MovieV2("Monsters Inc", 2001, "Pixar");

      System.out.println("    <<<< Before Sorting >>>> \n");
      arrPrinter(films);

      films = insertionTitle(films, 1);
        
      System.out.println("\n     <<<< After Sorting >>>>");
      System.out.println("<<<< by title in ascending order >>>>\n");
      arrPrinter(films);
      
      films = insertionTitle(films, 2);
        
      System.out.println("\n     <<<< After Sorting >>>>");
      System.out.println("<<<< by title in descending order >>>>\n");
      arrPrinter(films);
            
      films = insertionYear(films, 1);

      System.out.println("\n     <<<< After Sorting >>>>");
      System.out.println("<<<< by year in ascending order>>>>\n");
      arrPrinter(films);
      
      films = insertionYear(films, 2);

      System.out.println("\n     <<<< After Sorting >>>>");
      System.out.println("<<<< by year in descending order>>>>\n");
      arrPrinter(films);
            
      films = insertionStudio(films, 1);

      System.out.println("\n     <<<< After Sorting >>>>");
      System.out.println("<<<< by studio in ascending order >>>>\n");
      arrPrinter(films);
      
      films = insertionStudio(films, 2);

      System.out.println("\n     <<<< After Sorting >>>>");
      System.out.println("<<<< by studio in descending order >>>>\n");
      arrPrinter(films);
    }
}
