
/**
 * Purpose: Creates an array of movie objects and sorts them.
 *
 * @author (Jack Moran)
 * @version (4/26/18)
 */
public class MovieTesterV3
{
  public static void arrPrinter(MovieV3[] films)
  {
    for (MovieV3 film : films)
     System.out.println(film);
  }
  
  public static void selectionTitle(MovieV3[] source, int which)
  {
    if (which == 1)
    {
      int i;
      int k;
      int posMax;
      MovieV3 temp;

      for ( i = source.length - 1 ; i >= 0 ; i-- )
      {
        // find largest element in the i elements
        posMax = 0;
        for ( k = 0 ; k <= i ; k++ )
        {
          if ( source[ k ].getTitle().compareTo(source[ posMax ].getTitle()) > 0 )
           posMax = k;
        }
        // swap the item with the largest cost 
        // with the element in position i
        // now the item is in its proper location
        temp = source[ i ];
        source[ i ] = source[posMax ];
        source[ posMax ] = temp;
      }
    }
    else if (which == 2)
    {
      int i;
      int k;
      int posMax;
      MovieV3 temp;

      for ( i = source.length - 1 ; i >= 0 ; i-- )
      {
        // find largest element in the i elements
        posMax = 0;
        for ( k = 0 ; k <= i ; k++ )
        {
          if ( source[ k ].getTitle().compareTo(source[ posMax ].getTitle()) < 0 )
           posMax = k;
        }
        // swap the item with the largest cost 
        // with the element in position i
        // now the item is in its proper location
        temp = source[ i ];
        source[ i ] = source[posMax ];
        source[ posMax ] = temp;
      }
    }
  }
  
  public static void selectionYear(MovieV3[] source, int which)
  {
    if (which == 1)
    {
      int i;
      int k;
      int posMax;
      MovieV3 temp;

      for ( i = source.length - 1 ; i >= 0 ; i-- )
      {
        // find largest element in the i elements
        posMax = 0;
        for ( k = 0 ; k <= i ; k++ )
        {
          if ( source[ k ].getYear() > source[ posMax ].getYear() )
           posMax = k;
        }
        // swap the item with the largest cost 
        // with the element in position i
        // now the item is in its proper location
        temp = source[ i ];
        source[ i ] = source[posMax ];
        source[ posMax ] = temp;
      }
    }
    else if (which == 2)
    {
      int i;
      int k;
      int posMax;
      MovieV3 temp;

      for ( i = source.length - 1 ; i >= 0 ; i-- )
      {
        // find largest element in the i elements
        posMax = 0;
        for ( k = 0 ; k <= i ; k++ )
        {
          if ( source[ k ].getYear() < source[ posMax ].getYear() )
           posMax = k;
        }
        // swap the item with the largest cost 
        // with the element in position i
        // now the item is in its proper location
        temp = source[ i ];
        source[ i ] = source[posMax ];
        source[ posMax ] = temp;
      }
    }
  }
  
  public static void selectionStudio(MovieV3[] source, int which)
  {
    if (which == 1)
    {
      int i;
      int k;
      int posMax;
      MovieV3 temp;

      for ( i = source.length - 1 ; i >= 0 ; i-- )
      {
        // find largest element in the i elements
        posMax = 0;
        for ( k = 0 ; k <= i ; k++ )
        {
          if ( source[ k ].getStudio().compareTo(source[ posMax ].getStudio()) > 0 )
           posMax = k;
        }
        // swap the item with the largest cost 
        // with the element in position i
        // now the item is in its proper location
        temp = source[ i ];
        source[ i ] = source[posMax ];
        source[ posMax ] = temp;
      }
    }
    else if (which == 2)
    {
      int i;
      int k;
      int posMax;
      MovieV3 temp;

      for ( i = source.length - 1 ; i >= 0 ; i-- )
      {
        // find largest element in the i elements
        posMax = 0;
        for ( k = 0 ; k <= i ; k++ )
        {
          if ( source[ k ].getStudio().compareTo(source[ posMax ].getStudio()) < 0 )
           posMax = k;
        }
        // swap the item with the largest cost 
        // with the element in position i
        // now the item is in its proper location
        temp = source[ i ];
        source[ i ] = source[posMax ];
        source[ posMax ] = temp;
      }
    }
  }
  
  public static void main(String[] args)
  {
      MovieV3[] films = new MovieV3[10];

      films[0] = new MovieV3("Inside Out", 2016, "Pixar");
      films[1] = new MovieV3("Coco", 2017, "Pixar");
      films[2] = new MovieV3("Wreck-It Ralph", 2012, "Disney");
      films[3] = new MovieV3("Wizard of Oz", 1939, "MGM");
      films[4] = new MovieV3("Moana", 2016, "Disney");
      films[5] = new MovieV3("Hotel Transylvania", 2012, "Sony Pictures Animation");
      films[6] = new MovieV3("Shrek", 2001, "Dreamworks");
      films[7] = new MovieV3("The Emoji Movie", 2017, "Sony Pictures Animation");
      films[8] = new MovieV3("WALL-E", 2008, "Pixar");
      films[9] = new MovieV3("Monsters Inc", 2001, "Pixar");

      System.out.println("    <<<< Before Sorting >>>> \n");
      arrPrinter(films);

      selectionTitle(films, 1);
        
      System.out.println("\n     <<<< After Sorting >>>>");
      System.out.println("<<<< by title in ascending order >>>>\n");
      arrPrinter(films);
      
      selectionTitle(films, 2);
        
      System.out.println("\n     <<<< After Sorting >>>>");
      System.out.println("<<<< by title in descending order >>>>\n");
      arrPrinter(films);
            
      selectionYear(films, 1);

      System.out.println("\n     <<<< After Sorting >>>>");
      System.out.println("<<<< by year in ascending order>>>>\n");
      arrPrinter(films);
      
      selectionYear(films, 2);

      System.out.println("\n     <<<< After Sorting >>>>");
      System.out.println("<<<< by year in descending order>>>>\n");
      arrPrinter(films);
            
      selectionStudio(films, 1);

      System.out.println("\n     <<<< After Sorting >>>>");
      System.out.println("<<<< by studio in ascending order >>>>\n");
      arrPrinter(films);
      
      selectionStudio(films, 2);

      System.out.println("\n     <<<< After Sorting >>>>");
      System.out.println("<<<< by studio in descending order >>>>\n");
      arrPrinter(films);
  }
}
