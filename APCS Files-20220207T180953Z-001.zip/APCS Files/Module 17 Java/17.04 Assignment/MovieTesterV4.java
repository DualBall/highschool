
/**
 * Purpose: Creates an array of movie objects and sorts them.
 *
 * @author (Jack Moran)
 * @version (4/26/18)
 */
public class MovieTesterV4
{
  public static void arrPrinter(MovieV4[] films)
  {
    for (MovieV4 film : films)
     System.out.println(film);
  }
  
  public static void mergeSortTitle(MovieV4[] source, int low, int high)
  {
     if( low == high )
            return;

        int mid = ( low + high ) / 2;

        mergeSortTitle( source, low, mid );       // recursive call
        mergeSortTitle( source, mid + 1, high);   // recursive call

        //Debugging Statements 
        //uncomment to print the listings after each pass through the sort
        //System.out.println("\nCurrent list");
        //for(HouseListing h : a)  
        //    if( h != null) System.out.printf("$%10.2f \n", h.getCost() );
                
        mergeTitle( source, low, mid, high);
  }
  
  public static void mergeTitle (MovieV4[] source, int low, int mid, int high)
  {
    MovieV4[] temp = new MovieV4[ high - low + 1 ];

        int i = low, j = mid + 1, n = 0;

        while( i <= mid || j <= high )
        {
            if( i > mid )
            {
                temp[ n ] = source[ j ];
                j++;
            }
            else if( j > high )
            {
                temp[ n ] = source[ i ];
                i++;
            }
            else if( source[ i ].getTitle().compareTo(source[ j ].getTitle()) < 0 )
            {
                temp[ n ] = source[ i ];
                i++;
            }
            else
            {
                temp[ n ] = source[ j ];
                j++;
            }
            n++;
        }

        for( int k = low ; k <= high ; k++ )
            source[ k ] = temp[ k - low ];
  }
  
  public static void mergeSortYear(MovieV4[] source, int low, int high)
  {
     if( low == high )
            return;

        int mid = ( low + high ) / 2;

        mergeSortYear( source, low, mid );       // recursive call
        mergeSortYear( source, mid + 1, high);   // recursive call

        //Debugging Statements 
        //uncomment to print the listings after each pass through the sort
        //System.out.println("\nCurrent list");
        //for(HouseListing h : a)  
        //    if( h != null) System.out.printf("$%10.2f \n", h.getCost() );
                
        mergeYear( source, low, mid, high);
  }
  
  public static void mergeYear (MovieV4[] source, int low, int mid, int high)
  {
    MovieV4[] temp = new MovieV4[ high - low + 1 ];

        int i = low, j = mid + 1, n = 0;

        while( i <= mid || j <= high )
        {
            if( i > mid )
            {
                temp[ n ] = source[ j ];
                j++;
            }
            else if( j > high )
            {
                temp[ n ] = source[ i ];
                i++;
            }
            else if( source[ i ].getYear() < source[ j ].getYear() )
            {
                temp[ n ] = source[ i ];
                i++;
            }
            else
            {
                temp[ n ] = source[ j ];
                j++;
            }
            n++;
        }

        for( int k = low ; k <= high ; k++ )
            source[ k ] = temp[ k - low ];
  }
  
  public static void mergeSortStudio(MovieV4[] source, int low, int high)
  {
     if( low == high )
            return;

        int mid = ( low + high ) / 2;

        mergeSortStudio( source, low, mid );       // recursive call
        mergeSortStudio( source, mid + 1, high);   // recursive call

        //Debugging Statements 
        //uncomment to print the listings after each pass through the sort
        //System.out.println("\nCurrent list");
        //for(HouseListing h : a)  
        //    if( h != null) System.out.printf("$%10.2f \n", h.getCost() );
                
        mergeStudio( source, low, mid, high);
  }
  
  public static void mergeStudio (MovieV4[] source, int low, int mid, int high)
  {
    MovieV4[] temp = new MovieV4[ high - low + 1 ];

        int i = low, j = mid + 1, n = 0;

        while( i <= mid || j <= high )
        {
            if( i > mid )
            {
                temp[ n ] = source[ j ];
                j++;
            }
            else if( j > high )
            {
                temp[ n ] = source[ i ];
                i++;
            }
            else if( source[ i ].getStudio().compareTo(source[ j ].getStudio()) < 0 )
            {
                temp[ n ] = source[ i ];
                i++;
            }
            else
            {
                temp[ n ] = source[ j ];
                j++;
            }
            n++;
        }

        for( int k = low ; k <= high ; k++ )
            source[ k ] = temp[ k - low ];
  }
  
  public static void main(String[] args)
  {
      MovieV4[] films = new MovieV4[10];

      films[0] = new MovieV4("Inside Out", 2016, "Pixar");
      films[1] = new MovieV4("Coco", 2017, "Pixar");
      films[2] = new MovieV4("Wreck-It Ralph", 2012, "Disney");
      films[3] = new MovieV4("Wizard of Oz", 1939, "MGM");
      films[4] = new MovieV4("Moana", 2016, "Disney");
      films[5] = new MovieV4("Hotel Transylvania", 2012, "Sony Pictures Animation");
      films[6] = new MovieV4("Shrek", 2001, "Dreamworks");
      films[7] = new MovieV4("The Emoji Movie", 2017, "Sony Pictures Animation");
      films[8] = new MovieV4("WALL-E", 2008, "Pixar");
      films[9] = new MovieV4("Monsters Inc", 2001, "Pixar");

      System.out.println("    <<<< Before Sorting >>>> \n");
      arrPrinter(films);

      mergeSortTitle(films, 0, films.length - 1);
        
      System.out.println("\n     <<<< After Sorting >>>>");
      System.out.println("<<<< by title in ascending order >>>>\n");
      arrPrinter(films);
 
            
      mergeSortYear(films, 0, films.length - 1);

      System.out.println("\n     <<<< After Sorting >>>>");
      System.out.println("<<<< by year in ascending order>>>>\n");
      arrPrinter(films);
            
      mergeSortStudio(films, 0, films.length - 1);

      System.out.println("\n     <<<< After Sorting >>>>");
      System.out.println("<<<< by studio in ascending order >>>>\n");
      arrPrinter(films);
  }
}
