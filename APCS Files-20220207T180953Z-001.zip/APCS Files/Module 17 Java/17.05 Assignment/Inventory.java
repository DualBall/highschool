
/**
 * Purpose: creates an object that defines a store item.
 *
 * @author (Jack Moran)
 * @version (4/28/18)
 */
public class Inventory
{
    // instance variables - replace the example below with your own
    private int number, quantity;
    private double price;
    private String name;

    /**
     * Constructor for objects of class Inventory
     */
    public Inventory(String name, int number, double price, int quantity)
    {
      this.name = name;
      this.number = number;
      this.price = price;
      this.quantity = quantity;
    }

    public String getName()
    {
      return name;
    }
    
    public int getNumber()
    {
      return number;
    }
    
    public double getPrice()
    {
      return price;
    }
    
    public int getQuantity()
    {
      return quantity;
    }
    
    public String toString()
    {
      String str = String.format("%-30s %7d         $%8.2f %10d", name, number, price,
      quantity);
      return str;
    }
}
