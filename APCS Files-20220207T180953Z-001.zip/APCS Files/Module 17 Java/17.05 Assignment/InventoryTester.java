
/**
 * Creates and sorts an array of inventory objects using various algorithms.
 *
 * @author (Jack Moran)
 * @version (4/30/18)
 */
public class InventoryTester
{
  public static void arrPrinter(Inventory[] stock)
  {
    System.out.print(" Name                             Number          Price");
    System.out.println("      Quantity");
    System.out.print("----------------------------------------------------");
    System.out.println("--------------------");
    for (Inventory stocks : stock)
     System.out.println(stocks);
  }
  
  public static void selectionName(Inventory[] source, int which)
  {
    if (which == 1)
    {
      int i;
      int k;
      int posMax;
      Inventory temp;

      for ( i = source.length - 1 ; i >= 0 ; i-- )
      {
        posMax = 0;
        for ( k = 0 ; k <= i ; k++ )
        {
          if ( source[ k ].getName().compareTo(source[ posMax ].getName()) > 0 )
           posMax = k;
        }
        temp = source[ i ];
        source[ i ] = source[posMax ];
        source[ posMax ] = temp;
      }
    }
    else if (which == 2)
    {
      int i;
      int k;
      int posMax;
      Inventory temp;

      for ( i = source.length - 1 ; i >= 0 ; i-- )
      {
        posMax = 0;
        for ( k = 0 ; k <= i ; k++ )
        {
          if ( source[ k ].getName().compareTo(source[ posMax ].getName()) < 0 )
           posMax = k;
        }

        temp = source[ i ];
        source[ i ] = source[posMax ];
        source[ posMax ] = temp;
      }
    }
  }
  
  public static void mergeSortNum(Inventory[] source, int low, int high)
  {
     if( low == high )
            return;

        int mid = ( low + high ) / 2;

        mergeSortNum( source, low, mid );       // recursive call
        mergeSortNum( source, mid + 1, high);   // recursive call
                
        mergeNum( source, low, mid, high);
  }
  
  public static void mergeNum (Inventory[] source, int low, int mid, int high)
  {
    Inventory[] temp = new Inventory[ high - low + 1 ];

        int i = low, j = mid + 1, n = 0;

        while( i <= mid || j <= high )
        {
            if( i > mid )
            {
                temp[ n ] = source[ j ];
                j++;
            }
            else if( j > high )
            {
                temp[ n ] = source[ i ];
                i++;
            }
            else if( source[ i ].getNumber() < source[ j ].getNumber() )
            {
                temp[ n ] = source[ i ];
                i++;
            }
            else
            {
                temp[ n ] = source[ j ];
                j++;
            }
            n++;
        }

        for( int k = low ; k <= high ; k++ )
            source[ k ] = temp[ k - low ];
  }
  
  public static Inventory[] insertionPrice(Inventory[] source, int which)
  {
    Inventory[] dest = new Inventory[source.length];
    if (which == 1)
    {
     for( int i = 0 ; i < source.length ; i++ )
     {
       Inventory next = source[i];
       int insertIndex = 0;
       int k = i;
            
       while( k > 0 && insertIndex == 0 )
       {
         if(next.getPrice() > (dest[k-1].getPrice()))
         {
           insertIndex = k;
         }
         else
         {
          dest[ k ] = dest[ k - 1 ];
         }
         
         k--;
       }

       dest[insertIndex] = next;
     }
    }
    else if (which == 2)
    {
      for( int i = 0 ; i < source.length ; i++ )
      {
       Inventory next = source[i];
       int insertIndex = 0;
       int k = i;
            
       while( k > 0 && insertIndex == 0 )
       {
         if(next.getPrice() < (dest[k-1].getPrice()))
         {
           insertIndex = k;
         }
         else
         {
          dest[ k ] = dest[ k - 1 ];
         }
         
         k--;
       }

       dest[insertIndex] = next;
      }
    }
    return dest;
  }
  
  public static void mergeSortQuantity(Inventory[] source, int low, int high)
  {
     if( low == high )
            return;

        int mid = ( low + high ) / 2;

        mergeSortNum( source, low, mid );       // recursive call
        mergeSortNum( source, mid + 1, high);   // recursive call
                
        mergeNum( source, low, mid, high);
  }
  
  public static void mergeQuantity (Inventory[] source, int low, int mid, int high)
  {
    Inventory[] temp = new Inventory[ high - low + 1 ];

        int i = low, j = mid + 1, n = 0;

        while( i <= mid || j <= high )
        {
            if( i > mid )
            {
                temp[ n ] = source[ j ];
                j++;
            }
            else if( j > high )
            {
                temp[ n ] = source[ i ];
                i++;
            }
            else if( source[ i ].getQuantity() < source[ j ].getQuantity() )
            {
                temp[ n ] = source[ i ];
                i++;
            }
            else
            {
                temp[ n ] = source[ j ];
                j++;
            }
            n++;
        }

        for( int k = low ; k <= high ; k++ )
            source[ k ] = temp[ k - low ];
  }
  
  public static void main (String[] args)
  {
    Inventory[] stock = new Inventory[10];

      stock[0] = new Inventory("G-Fuel", 420, 15.50, 45);
      stock[1] = new Inventory("Pro-League Gaming Chair", 1000, 100.00, 10);
      stock[2] = new Inventory("Season 4 Pass", 1, 9.99, 500);
      stock[3] = new Inventory("SUPAH Mario Odyssey", 231, 300.00, 0);
      stock[4] = new Inventory("V-Bucks Plushie", 249, 12.50, 226);
      stock[5] = new Inventory("PUBG > Fortnite Poster", 140, 35.00, 12);
      stock[6] = new Inventory("Super Smash Bros 5", 50, 60.00, 0);
      stock[7] = new Inventory("Surviv.io: Deluxe Edition", 900, 60.00, 400);
      stock[8] = new Inventory("Phoenix Wright: Steamed Hams", 367, 60.00, 198);
      stock[9] = new Inventory("Knack II Bedsheet", 17, 1500.00, 500);

      System.out.println("    <<<< Before Sorting >>>> \n");
      arrPrinter(stock);
      
      selectionName(stock, 1);
        
      System.out.println("\n     <<<< After Sorting >>>>");
      System.out.println("<<<< by name in ascending order >>>>\n");
      arrPrinter(stock);
      
      selectionName(stock, 2);
        
      System.out.println("\n     <<<< After Sorting >>>>");
      System.out.println("<<<< by name in descending order >>>>\n");
      arrPrinter(stock);

      mergeSortNum(stock, 0, stock.length - 1);
        
      System.out.println("\n     <<<< After Sorting >>>>");
      System.out.println("<<<< by product number in ascending order >>>>\n");
      arrPrinter(stock);
      
      stock = insertionPrice(stock, 1);

      System.out.println("\n     <<<< After Sorting >>>>");
      System.out.println("<<<< by price in ascending order>>>>\n");
      arrPrinter(stock);
      
      stock = insertionPrice(stock, 2);

      System.out.println("\n     <<<< After Sorting >>>>");
      System.out.println("<<<< by price in descending order>>>>\n");
      arrPrinter(stock);
            
      mergeSortQuantity(stock, 0, stock.length - 1);

      System.out.println("\n     <<<< After Sorting >>>>");
      System.out.println("<<<< by quantity in ascending order>>>>\n");
      arrPrinter(stock);
  }
}
