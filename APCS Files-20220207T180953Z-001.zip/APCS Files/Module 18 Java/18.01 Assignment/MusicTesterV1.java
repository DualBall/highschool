
/**
 * Finds certain songs in an array of music objects.
 *
 * @author (Jack Moran)
 * @version (5/2/18)
 */
public class MusicTesterV1
{
  public static void arrPrinter(MusicV1[] songs)
  {
    for (MusicV1 song : songs)
     System.out.println(song);
  }
  
  public static void findTitle(MusicV1[] r, String toFind)
  {
        int found = 0;

        System.out.println("Find results: ");
        for(int i = 0; i < r.length; i++)
        {
            if(r[i].getTitle().compareTo(toFind) == 0)
            {
                System.out.println(r[i]);
                found++;
            }
        }
        
        if(found == 0)
        {   // we have not found the location
            System.out.println(toFind + " is not in the roster");
        }
  }
  
  public static void findYear(MusicV1[] r, int toFind)
  {
        int found = 0;

        System.out.println("Find results: ");
        for(int i = 0; i < r.length; i++)
        {
            if(r[i].getYear() == toFind)
            {
                System.out.println(r[i]);
                found++;
            }
        }
        
        if(found == 0)
        {   // we have not found the location
            System.out.println(toFind + " is not in the roster");
        }
  }
  
  public static void findArtist(MusicV1[] r, String toFind)
  {
        int found = 0;

        System.out.println("Find results: ");
        for(int i = 0; i < r.length; i++)
        {
            if(r[i].getArtist().compareTo(toFind) == 0)
            {
                System.out.println(r[i]);
                found++;
            }
        }
        
        if(found == 0)
        {   // we have not found the location
            System.out.println(toFind + " is not in the roster");
        }
  }
  
  public static void main(String[] args)
  {
      MusicV1[] songs = new MusicV1[10];

      songs[0] = new MusicV1("Super Mario Bros Theme", 1985, "Koji Kondo");
      songs[1] = new MusicV1("One", 1991, "U2");
      songs[2] = new MusicV1("Despacito", 2017, "Luis Fonsi");
      songs[3] = new MusicV1("With or Without You", 1987, "U2");
      songs[4] = new MusicV1("Remember Me", 2017, "Robert Lopez");
      songs[5] = new MusicV1("All Star", 1999, "Smash Mouth");
      songs[6] = new MusicV1("Uptown Funk", 2014, "Mark Ronson");
      songs[7] = new MusicV1("Fireflies", 2009, "Owl City");
      songs[8] = new MusicV1("When Can I See You Again?", 2012, "Owl City");
      songs[9] = new MusicV1("Shooting Stars", 2010, "Bag Raiders");

      arrPrinter(songs);
      
      System.out.println("\n\nSearching for Super Mario Bros Theme: ");
      findTitle(songs, "Super Mario Bros Theme");
      
      System.out.println("\n\nSearching for Pokemon Theme Song: ");
      findTitle(songs, "Pokemon Theme Song");
      
      System.out.println("\n\nSearching for songs from 2017: ");
      findYear(songs, 2017);
      
      System.out.println("\n\nSearching for songs from 2018: ");
      findYear(songs, 2018);
      
      System.out.println("\n\nSearching for songs by Owl City: ");
      findArtist(songs, "Owl City");
      
      System.out.println("\n\nSearching for songs by Crush 40: ");
      findArtist(songs, "Crush 40");
    }
}
