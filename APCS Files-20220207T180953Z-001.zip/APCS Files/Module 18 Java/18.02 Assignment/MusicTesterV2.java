
/**
 * Finds certain songs in an array of music objects.
 *
 * @author (Jack Moran)
 * @version (5/2/18)
 */
public class MusicTesterV2
{
  public static void arrPrinter(Music[] songs)
  {
    for (Music song : songs)
     System.out.println(song);
  }
  
  public static void mergeSortTitle(Music[] source, int low, int high)
  {
     if( low == high )
            return;

        int mid = ( low + high ) / 2;

        mergeSortTitle( source, low, mid );       // recursive call
        mergeSortTitle( source, mid + 1, high);   // recursive call

        //Debugging Statements 
        //uncomment to print the listings after each pass through the sort
        //System.out.println("\nCurrent list");
        //for(HouseListing h : a)  
        //    if( h != null) System.out.printf("$%10.2f \n", h.getCost() );
                
        mergeTitle( source, low, mid, high);
  }
  
  public static void mergeTitle (Music[] source, int low, int mid, int high)
  {
    Music[] temp = new Music[ high - low + 1 ];

        int i = low, j = mid + 1, n = 0;

        while( i <= mid || j <= high )
        {
            if( i > mid )
            {
                temp[ n ] = source[ j ];
                j++;
            }
            else if( j > high )
            {
                temp[ n ] = source[ i ];
                i++;
            }
            else if( source[ i ].getTitle().compareTo(source[ j ].getTitle()) < 0 )
            {
                temp[ n ] = source[ i ];
                i++;
            }
            else
            {
                temp[ n ] = source[ j ];
                j++;
            }
            n++;
        }

        for( int k = low ; k <= high ; k++ )
            source[ k ] = temp[ k - low ];
  }
  
  public static void mergeSortYear(Music[] source, int low, int high)
  {
     if( low == high )
            return;

        int mid = ( low + high ) / 2;

        mergeSortYear( source, low, mid );       // recursive call
        mergeSortYear( source, mid + 1, high);   // recursive call

        //Debugging Statements 
        //uncomment to print the listings after each pass through the sort
        //System.out.println("\nCurrent list");
        //for(HouseListing h : a)  
        //    if( h != null) System.out.printf("$%10.2f \n", h.getCost() );
                
        mergeYear( source, low, mid, high);
  }
  
  public static void mergeYear (Music[] source, int low, int mid, int high)
  {
    Music[] temp = new Music[ high - low + 1 ];

        int i = low, j = mid + 1, n = 0;

        while( i <= mid || j <= high )
        {
            if( i > mid )
            {
                temp[ n ] = source[ j ];
                j++;
            }
            else if( j > high )
            {
                temp[ n ] = source[ i ];
                i++;
            }
            else if( source[ i ].getYear() < source[ j ].getYear() )
            {
                temp[ n ] = source[ i ];
                i++;
            }
            else
            {
                temp[ n ] = source[ j ];
                j++;
            }
            n++;
        }

        for( int k = low ; k <= high ; k++ )
            source[ k ] = temp[ k - low ];
  }
  
  public static void mergeSortArtist(Music[] source, int low, int high)
  {
     if( low == high )
            return;

        int mid = ( low + high ) / 2;

        mergeSortArtist( source, low, mid );       // recursive call
        mergeSortArtist( source, mid + 1, high);   // recursive call

        //Debugging Statements 
        //uncomment to print the listings after each pass through the sort
        //System.out.println("\nCurrent list");
        //for(HouseListing h : a)  
        //    if( h != null) System.out.printf("$%10.2f \n", h.getCost() );
                
        mergeArtist( source, low, mid, high);
  }
  
  public static void mergeArtist (Music[] source, int low, int mid, int high)
  {
    Music[] temp = new Music[ high - low + 1 ];

        int i = low, j = mid + 1, n = 0;

        while( i <= mid || j <= high )
        {
            if( i > mid )
            {
                temp[ n ] = source[ j ];
                j++;
            }
            else if( j > high )
            {
                temp[ n ] = source[ i ];
                i++;
            }
            else if( source[ i ].getArtist().compareTo(source[ j ].getArtist()) < 0 )
            {
                temp[ n ] = source[ i ];
                i++;
            }
            else
            {
                temp[ n ] = source[ j ];
                j++;
            }
            n++;
        }

        for( int k = low ; k <= high ; k++ )
            source[ k ] = temp[ k - low ];
  }
  
  public static void findTitle(Music[] r, String toFind)
  {
        int high = r.length;
        int low = -1;
        int probe;

        while( high - low > 1 )
        {
            probe = ( high + low ) / 2;

            if(r[probe].getTitle().compareTo(toFind) > 0)
                high = probe;
            else
            {
                low = probe;
                if( r[probe].getTitle().compareTo(toFind) == 0)
                {
                    break;
                }
            }
        }
        
        if( (low >= 0) && (r[low].getTitle().compareTo(toFind) == 0 ))
        {
            linearPrintTitle(r, low, toFind);
        }
        else
            System.out.println("NOT found: " + toFind);
  }
  
  public static void linearPrintTitle(Music[] r, int low, String toFind)
    {
        int i;
        int start = low;
        int end = low;

        // find starting point of matches
        i = low - 1;
        while((i >= 0) && (r[i].getTitle().compareTo(toFind) == 0))
        {
            start = i;
            i--;
        }
        // find ending point of matches
        i = low + 1;
        while((i < r.length) && (r[i].getTitle().compareTo(toFind) == 0))
        {
            end = i;
            i++;
        }
        // now print out the matches
        for(i = start; i <= end; i++)
            System.out.println(r[i]);
    }
  
  public static void findYear(Music[] r, int toFind)
  {
        int high = r.length;
        int low = -1;
        int probe;

        while( high - low > 1 )
        {
            probe = ( high + low ) / 2;

            if(r[probe].getYear() > toFind)
                high = probe;
            else
            {
                low = probe;
                if( r[probe].getYear() == toFind)
                {
                    break;
                }
            }
        }
        
        if( (low >= 0) && (r[low].getYear() == toFind))
        {
            linearPrintYear(r, low, toFind);
        }
        else
            System.out.println("NOT found: " + toFind);
  }
  
  public static void linearPrintYear(Music[] r, int low, int toFind)
    {
        int i;
        int start = low;
        int end = low;

        // find starting point of matches
        i = low - 1;
        while((i >= 0) && (r[i].getYear() == toFind))
        {
            start = i;
            i--;
        }
        // find ending point of matches
        i = low + 1;
        while((i < r.length) && (r[i].getYear() == toFind))
        {
            end = i;
            i++;
        }
        // now print out the matches
        for(i = start; i <= end; i++)
            System.out.println(r[i]);
    }
  
  public static void findArtist(Music[] r, String toFind)
  {
        int high = r.length;
        int low = -1;
        int probe;

        while( high - low > 1 )
        {
            probe = ( high + low ) / 2;

            if(r[probe].getArtist().compareTo(toFind) > 0)
                high = probe;
            else
            {
                low = probe;
                if( r[probe].getArtist().compareTo(toFind) == 0)
                {
                    break;
                }
            }
        }
        
        if( (low >= 0) && (r[low].getArtist().compareTo(toFind) == 0 ))
        {
            linearPrintArtist(r, low, toFind);
        }
        else
            System.out.println("NOT found: " + toFind);
  }
  
  public static void linearPrintArtist(Music[] r, int low, String toFind)
    {
        int i;
        int start = low;
        int end = low;

        // find starting point of matches
        i = low - 1;
        while((i >= 0) && (r[i].getArtist().compareTo(toFind) == 0))
        {
            start = i;
            i--;
        }
        // find ending point of matches
        i = low + 1;
        while((i < r.length) && (r[i].getArtist().compareTo(toFind) == 0))
        {
            end = i;
            i++;
        }
        // now print out the matches
        for(i = start; i <= end; i++)
            System.out.println(r[i]);
    }
  
  public static void main(String[] args)
  {
      Music[] songs = new Music[10];

      songs[0] = new Music("Super Mario Bros Theme", 1985, "Koji Kondo");
      songs[1] = new Music("One", 1991, "U2");
      songs[2] = new Music("Despacito", 2017, "Luis Fonsi");
      songs[3] = new Music("With or Without You", 1987, "U2");
      songs[4] = new Music("Remember Me", 2017, "Robert Lopez");
      songs[5] = new Music("All Star", 1999, "Smash Mouth");
      songs[6] = new Music("Uptown Funk", 2014, "Mark Ronson");
      songs[7] = new Music("Fireflies", 2009, "Owl City");
      songs[8] = new Music("When Can I See You Again?", 2012, "Owl City");
      songs[9] = new Music("Shooting Stars", 2010, "Bag Raiders");

      arrPrinter(songs);
      
      System.out.println("\n\nSearching for Super Mario Bros Theme: ");
      mergeSortTitle(songs, 0, songs.length - 1);
      findTitle(songs, "Super Mario Bros Theme");
      
      System.out.println("\n\nSearching for Pokemon Theme Song: ");
      findTitle(songs, "Pokemon Theme Song");
      
      System.out.println("\n\nSearching for songs from 2017: ");
      mergeSortYear(songs, 0, songs.length - 1);
      findYear(songs, 2017);
      
      System.out.println("\n\nSearching for songs from 2018: ");
      findYear(songs, 2018);
      
      System.out.println("\n\nSearching for songs by Owl City: ");
      mergeSortArtist(songs, 0, songs.length - 1);
      findArtist(songs, "Owl City");
      
      System.out.println("\n\nSearching for songs by Crush 40: ");
      findArtist(songs, "Crush 40");
    }
}
