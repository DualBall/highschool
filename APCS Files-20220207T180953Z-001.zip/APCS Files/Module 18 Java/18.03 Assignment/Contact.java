/**
 * Purpose: Creates an object representing a contact.
 *
 * @author (Jack Moran)
 * @version (5/3/18)
 *
 */
public class Contact
{
    // instance variables
    private String name, relation, birthday, phone, email;

    // Constructor for objects of class Music
    public Contact(String name, String relation, String birthday, String phone, String email)
    {
        // initialize instance variables
        this.name = name;
        this.relation = relation;
        this.birthday = birthday;
        this.phone = phone;
        this.email = email;
    }

    public String getName()
    {
        return name;
    }
   
    public String getRelation()
    {
        return relation;
    }
    
    public String getBirth()
    {
        return birthday;
    }
    
    public String getPhone()
    {
        return phone;
    }
    
    public String getEmail()
    {
        return email;
    }
   
    public String toString()
    {
        String str = name + " " + relation + " " + birthday + " " + phone +
        " " + email + " ";
        return str;
    }
}