
/**
 * Purpose: Searches for various contact objects in an array.
 *
 * @author (Jack Moran)
 * @version (5/3/18)
 */
public class ContactTester
{
  public static void arrPrinter(Contact[] contacts)
  {
    for (Contact contact : contacts)
     System.out.println(contact);
  }
  
  public static void mergeSortName(Contact[] source, int low, int high)
  {
     if( low == high )
            return;

        int mid = ( low + high ) / 2;

        mergeSortName( source, low, mid );       // recursive call
        mergeSortName( source, mid + 1, high);   // recursive call

        //Debugging Statements 
        //uncomment to print the listings after each pass through the sort
        //System.out.println("\nCurrent list");
        //for(Contact h : a)  
        //    if( h != null) System.out.printf("%20s \n", h.getName() );
                
        mergeName( source, low, mid, high);
  }
  
  public static void mergeName (Contact[] source, int low, int mid, int high)
  {
    Contact[] temp = new Contact[ high - low + 1 ];

        int i = low, j = mid + 1, n = 0;

        while( i <= mid || j <= high )
        {
            if( i > mid )
            {
                temp[ n ] = source[ j ];
                j++;
            }
            else if( j > high )
            {
                temp[ n ] = source[ i ];
                i++;
            }
            else if( source[ i ].getName().compareTo(source[ j ].getName()) < 0 )
            {
                temp[ n ] = source[ i ];
                i++;
            }
            else
            {
                temp[ n ] = source[ j ];
                j++;
            }
            n++;
        }

        for( int k = low ; k <= high ; k++ )
            source[ k ] = temp[ k - low ];
  }
  
  public static void mergeSortRelation(Contact[] source, int low, int high)
  {
     if( low == high )
            return;

        int mid = ( low + high ) / 2;

        mergeSortRelation( source, low, mid );       // recursive call
        mergeSortRelation( source, mid + 1, high);   // recursive call

        //Debugging Statements 
        //uncomment to print the listings after each pass through the sort
        //System.out.println("\nCurrent list");
        //for(Contact h : a)  
        //    if( h != null) System.out.printf("%20s \n", h.getName() );
                
        mergeRelation( source, low, mid, high);
  }
  
  public static void mergeRelation (Contact[] source, int low, int mid, int high)
  {
    Contact[] temp = new Contact[ high - low + 1 ];

        int i = low, j = mid + 1, n = 0;

        while( i <= mid || j <= high )
        {
            if( i > mid )
            {
                temp[ n ] = source[ j ];
                j++;
            }
            else if( j > high )
            {
                temp[ n ] = source[ i ];
                i++;
            }
            else if( source[ i ].getRelation().compareTo(source[ j ].getRelation()) < 0 )
            {
                temp[ n ] = source[ i ];
                i++;
            }
            else
            {
                temp[ n ] = source[ j ];
                j++;
            }
            n++;
        }

        for( int k = low ; k <= high ; k++ )
            source[ k ] = temp[ k - low ];
  }
  
  public static void findName(Contact[] r, String toFind)
  {
        int high = r.length;
        int low = -1;
        int probe;

        while( high - low > 1 )
        {
            probe = ( high + low ) / 2;

            if(r[probe].getName().compareTo(toFind) > 0)
                high = probe;
            else
            {
                low = probe;
                if( r[probe].getName().compareTo(toFind) == 0)
                {
                    break;
                }
            }
        }
        
        if( (low >= 0) && (r[low].getName().compareTo(toFind) == 0 ))
        {
            System.out.println(r[low]);
        }
        else
            System.out.println("NOT found: " + toFind);
  }
  
  public static void findRelation(Contact[] r, String toFind)
  {
        int high = r.length;
        int low = -1;
        int probe;

        while( high - low > 1 )
        {
            probe = ( high + low ) / 2;

            if(r[probe].getRelation().compareTo(toFind) > 0)
                high = probe;
            else
            {
                low = probe;
                if( r[probe].getRelation().compareTo(toFind) == 0)
                {
                    break;
                }
            }
        }
        
        if( (low >= 0) && (r[low].getRelation().compareTo(toFind) == 0 ))
        {
            linearPrintRelation(r, low, toFind);
        }
        else
            System.out.println("NOT found: " + toFind);
  }
  
  public static void linearPrintRelation(Contact[] r, int low, String toFind)
  {
        int i;
        int start = low;
        int end = low;

        // find starting point of matches
        i = low - 1;
        while((i >= 0) && (r[i].getRelation().compareTo(toFind) == 0))
        {
            start = i;
            i--;
        }
        // find ending point of matches
        i = low + 1;
        while((i < r.length) && (r[i].getRelation().compareTo(toFind) == 0))
        {
            end = i;
            i++;
        }
        // now print out the matches
        for(i = start; i <= end; i++)
            System.out.println(r[i]);
  }
  
  public static void findMonth(Contact[] r, String toFind)
  {
        int found = 0;

        System.out.println("Find results: ");
        for(int i = 0; i < r.length; i++)
        {
            if(r[i].getBirth().substring(0, 3).compareTo(toFind) == 0)
            {
                System.out.println(r[i]);
                found++;
            }
        }
        
        if(found == 0)
        {   // we have not found the location
            System.out.println(toFind + " is not in the roster");
        }
  }
  
  public static void findPhone(Contact[] r, String toFind)
  {
        int found = 0;

        System.out.println("Find results: ");
        for(int i = 0; i < r.length; i++)
        {
            if(r[i].getPhone().compareTo(toFind) == 0)
            {
                System.out.println(r[i]);
                found++;
            }
        }
        
        if(found == 0)
        {   // we have not found the location
            System.out.println(toFind + " is not in the roster");
        }
  }
  
  public static void findEmail(Contact[] r, String toFind)
  {
        int found = 0;

        System.out.println("Find results: ");
        for(int i = 0; i < r.length; i++)
        {
            if(r[i].getEmail().compareTo(toFind) == 0)
            {
                System.out.println(r[i]);
                found++;
            }
        }
        
        if(found == 0)
        {   // we have not found the location
            System.out.println(toFind + " is not in the roster");
        }
  }
    
  public static void main(String[] args)
  {
      Contact[] contacts = new Contact[10];

      contacts[0] = new Contact("T'Challa", "cousin", "Feb 16",
      "194-056-0757", "blackpanther@wakanda.net");
      contacts[1] = new Contact("Stephen Strange", "uncle", "Oct 20",
      "495-291-3408", "doctorstrange@kamartaj.org");
      contacts[2] = new Contact("Peter Parker", "brother", "Jun 28",
      "023-038-5347", "spiderman@newyork.com");
      contacts[3] = new Contact("Tony Stark", "uncle", "May 3",
      "395-597-3293", "ironman@newyork.com");
      contacts[4] = new Contact("Bruce Banner", "father", "Jun 13",
      "347-581-2395", "thehulk@culveruniversity.edu");
      contacts[5] = new Contact("Steve Rogers", "grandfather", "May 6",
      "576-102-2340", "captainamerica@unitedstates.gov");
      contacts[6] = new Contact("Thor", "ancestor", "Nov 3", "683-210-4587",
      "thor@asgard.gov");
      contacts[7] = new Contact("Loki Laufeyson", "ancestor", "Nov 3",
      "538-129-234", "loki@asgard.gov");
      contacts[8] = new Contact("Carol Danvers", "mother", "Mar 6",
      "305-302-5469", "captainmarvel@???.com");
      contacts[9] = new Contact("Thanos", "stepfather", "Apr 27",
      "555-555-5555", "thanos@titan.com");

      arrPrinter(contacts);
      
      System.out.println("\n\nSearching for Thanos: ");
      mergeSortName(contacts, 0, contacts.length - 1);
      findName(contacts, "Thanos");
      
      System.out.println("\n\nSearching for Matthew Murdock: ");
      findName(contacts, "Matthew Murdock");
      
      System.out.println("\n\nSearching for ancestors: ");
      mergeSortRelation(contacts, 0, contacts.length - 1);
      findRelation(contacts, "ancestor");
      
      System.out.println("\n\nSearching for aunts: ");
      findRelation(contacts, "aunt");
      
      System.out.println("\n\nSearching for contacts born in May: ");
      findMonth(contacts, "May");
      
      System.out.println("\n\nSearching for contacts born in January: ");
      findMonth(contacts, "Jan");
      
      System.out.println("\n\nSearching for phone number 555-555-5555: ");
      findPhone(contacts, "555-555-5555");
      
      System.out.println("\n\nSearching for phone number 123-456-7890: ");
      findPhone(contacts, "123-456-7890");
      
      System.out.println("\n\nSearching for email captainmarvel@???.com: ");
      findEmail(contacts, "captainmarvel@???.com");
      
      System.out.println("\n\nSearching for email outof@ideas.net: ");
      findEmail(contacts, "outof@ideas.net");
    }
}
