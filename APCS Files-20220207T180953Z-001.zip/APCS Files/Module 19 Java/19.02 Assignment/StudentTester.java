/**
 * Tests the student class and the exceptions it throws.
 *
 * @author (Jack Moran)
 * @version (5/7/18)
 */
public class StudentTester
{
  public static void main(String[] args)
  {
    //declares arrays to test with
    double[] scores1 = {89.50, 78.00, 95.00, 63.50, 94.00};
    double[] scores2 = {88.00, 90.50, 100.00, 88.50, 90.00, 100.00};
    double[] scores3 = {100.00, 60.50};
    double[] scores4 = {};
    
    //three successful constructions, with results printed
    Student peter = new Student("Peter", "Parker", scores1);
    Student tony = new Student("Tony", "Stark", scores2);
    Student bruce = new Student("Bruce", "Banner", scores3);
    
    System.out.println(peter);
    System.out.println(tony);
    System.out.println(bruce);
    
    //a call with an empty first name
    //Student steven = new Student("", "Strange", scores2);
    
    //a call with an empty last name
    //Student thor = new Student("Thor", "", scores1);
    
    //a call with an empty set of scores
    //Student thanos = new Student("Thanos", "Squidward", scores4);
  }
}