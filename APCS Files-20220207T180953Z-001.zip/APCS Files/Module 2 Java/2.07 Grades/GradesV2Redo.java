
/**
 * The purpose of this program is to calculate the total points and average
 * grade each time a new score is added to the total.
 * 
 * @author Jack Moran
 * @version 08/25/17
 */
public class GradesV2Redo
{
    public static void main(String[ ] args)
    {
        //local variables
        int numTests = 1;      //counts number of tests
        int testGrade1 = 95;     //individual test grade
        int totalPoints = 95;   //total points for all tests 
        double average = 95.0;  //average grade
        
        //test statistic format
        System.out.print("Test # " + numTests);
        System.out.print("  Test Grade: " + testGrade1);
        System.out.print("  Total points: " + totalPoints);
        System.out.println("   Average score: " + average);
        
        numTests ++;
        int testGrade2 = 73;
        totalPoints += testGrade2; 
        average = (double)totalPoints / (double)numTests;
        
        System.out.print("Test # " + numTests);
        System.out.print("  Test Grade: " + testGrade2);
        System.out.print("  Total points: " + totalPoints);
        System.out.println("  Average score: " + average);
        
        numTests ++;
        int testGrade3 = 91;
        totalPoints += testGrade3; 
        average = (double)totalPoints / (double)numTests;
        
        System.out.print("Test # " + numTests);
        System.out.print("  Test Grade: " + testGrade3);
        System.out.print("  Total points: " + totalPoints);
        System.out.println("  Average score: " + average);
        
        numTests ++;
        int testGrade4 = 82;
        totalPoints += testGrade4; 
        average = (double)totalPoints / (double)numTests;
        
        System.out.print("Test # " + numTests);
        System.out.print("  Test Grade: " + testGrade4);
        System.out.print("  Total points: " + totalPoints);
        System.out.println("  Average score: " + average);
        
        numTests ++;
        int testGrade5 = 67;
        totalPoints += testGrade5; 
        average = (double)totalPoints / (double)numTests;
        
        System.out.print("Test # " + numTests);
        System.out.print("  Test Grade: " + testGrade5);
        System.out.print("  Total points: " + totalPoints);
        System.out.println("  Average score: " + average);
        
        numTests ++;
        int testGrade6 = 77;
        totalPoints += testGrade6; 
        average = (double)totalPoints / (double)numTests;
        
        System.out.print("Test # " + numTests);
        System.out.print("  Test Grade: " + testGrade6);
        System.out.print("  Total points: " + totalPoints);
        System.out.println("  Average score: " + average);
        
        numTests ++;
        int testGrade7 = 54;
        totalPoints += testGrade7; 
        average = (double)totalPoints / (double)numTests;
        
        System.out.print("Test # " + numTests);
        System.out.print("  Test Grade: " + testGrade7);
        System.out.print("  Total points: " + totalPoints);
        System.out.println("  Average score: " + average);
        
        numTests ++;
        int testGrade8 = 89;
        totalPoints += testGrade8; 
        average = (double)totalPoints / (double)numTests;
        
        System.out.print("Test # " + numTests);
        System.out.print("  Test Grade: " + testGrade8);
        System.out.print("  Total points: " + totalPoints);
        System.out.println("  Average score: " + average);
        
        numTests ++;
        int testGrade9 = 100;
        totalPoints += testGrade9; 
        average = (double)totalPoints / (double)numTests;
        
        System.out.print("Test # " + numTests);
        System.out.print("  Test Grade: " + testGrade9);
        System.out.print("  Total points: " + totalPoints);
        System.out.println("  Average score: " + average);
    }//end of main method
}//end of class