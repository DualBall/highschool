
/**
 * The Currency class converts an amount of money from a specific
 * country into the equivalent currency of another country given 
 * the current exchange rate.
 *
 * @author Jack Moran
 * @version 08/28/17
 */
public class CurrencyConversionV1Redo
{
    public static void main(String [ ] args)
    {
        //Declare and initialize local variables
        double startingUsDollars = 6500.00; // starting US Dollars

        double pesosSpent = 7210.25;  // Mexican Pesos spent
        double pesoExchangeRate = 0.0598;  // 1 US dollar = 16.72 pesos
        double dollarsSpentInMexico = pesosSpent * pesoExchangeRate;  // US dollars spent in Mexico
        double dollarsAfterMexico = startingUsDollars - dollarsSpentInMexico;  // US dollars remaining after Mexico
        
        double cadSpent = 2805.50; // Canadian Dollars spent
        double cadExchangeRate = 0.8458; // 1 US dollar = 1.18 CAD
        double dollarsSpentInCanada = cadSpent * cadExchangeRate; // US dollars spent in Canada
        double dollarsAfterCanada = dollarsAfterMexico - dollarsSpentInCanada; // US dollars remaining after Canada
        
        double poundsSpent = 888.67; // British Pounds spent
        double poundExchangeRate = 1.3622; // 1 US dollar = 0.73
        double dollarsSpentInBritain = poundsSpent * poundExchangeRate; // US dollars spent in Britain
        double dollarsAfterBritain = dollarsAfterCanada - dollarsSpentInBritain; // US dollars remaining after Britain

        // Message to user stating purpose
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        System.out.println("This program converts an amount of money");
        System.out.println("from a specific country into the equivalent");
        System.out.println("currency of another country given the current");
        System.out.println("exchange rate.");
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        System.out.println();
        
        //Conversion
        System.out.println("Starting US Dollars : " + (startingUsDollars));
        System.out.println();
        
        System.out.println("Mexico:");
        System.out.println(" Pesos spent: " + pesosSpent);
        System.out.println(" US dollars equivalent: " + dollarsSpentInMexico);
        System.out.println(" US dollars remaining: " + dollarsAfterMexico);
        System.out.println();
        
        System.out.println("Canada:");
        System.out.println(" Canadian dollars spent: " + cadSpent);
        System.out.println(" US dollars equivalent: " + dollarsSpentInCanada);
        System.out.println(" US dollars remaining: " + dollarsAfterCanada);
        System.out.println();
        
        System.out.println("Britain:");
        System.out.println(" British pounds spent: " + poundsSpent);
        System.out.println(" US dollars equivalent: " + dollarsSpentInBritain);
        System.out.println(" US dollars remaining: " + dollarsAfterBritain);
        
        //Souvenir Purchases
 	System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
	System.out.println("Souvenir Purchases");
	System.out.println(" (all values in US Dollars) ");
	System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

	//Calculations for Souvenir #1
	int costItem1 = 12;  //cost per item of first souvenir
	int budget1 = 100;  //budget for first item
	int totalItems1 = budget1/costItem1; //how many items can be purchased
	int fundsRemaining1 = budget1%costItem1;  //how much of the budget is left

	System.out.println("Item 1");
	System.out.println(" Cost per item: $" + costItem1 );
	System.out.println(" Budget: $"+ budget1);
	System.out.println(" Total items purchased: " +  totalItems1);
	System.out.println(" Funds remaining: $"  +  fundsRemaining1);
     	System.out.println();

	//Calculations for Souvenir #2
	double costItem2 = 29.99;  //cost per item of second souvenir
	int budget2 = 500;   //budget for second item
	int totalItems2 = budget2/(int)costItem2; 	//how many items can be purchased
	double fundsRemaining2 = budget2 % costItem2;  	//how much of the budget is left

	System.out.println("Item 2");
	System.out.println("   Cost per item: $" + costItem2 );
	System.out.println("   Budget: $"+ budget2);
	System.out.println("   Total items purchased: " +  totalItems2);
	System.out.println("   Funds remaining: $"  +  fundsRemaining2);

    } // end of main method
} // end of class
