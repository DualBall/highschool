
/**
 * This program, when ran, will create ASCII art of an umbrella and some rain.
 *
 * @author Jack Moran
 * @version 8/30/17
 */
public class ArtWork
{
  public static void main(String[] args)
 {
   String row01 = "'  '  '  '  '  ' ";
   String row02 = "  '  '  '  '  '  ";  
   String row05 = "   __________   ";
   String row06 = "  /    |     \\ ";
   String row07 = " /_____|______\\";
   String row08 = "       |        ";
   String row09 = "       |        ";
   String row10 = "       (        ";
   
   System.out.print("\n" + row01 + "\n" + row02);
   System.out.print("\n" + row01 + "\n" + row02);
   System.out.print("\n" + row05 + "\n" + row06);
   System.out.print("\n" + row07 + "\n" + row08);
   System.out.print("\n" + row09 + "\n" + row10);   
 }    
}
