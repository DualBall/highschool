
/**
 * The purpose of this program is to allow the user to input 3 test scores,
 * and to calculate total points and average grade after each score.
 *
 *
 * @author Jack Moran
 * @version 9/1/17
 */
import java.util.Scanner; //imports Scanner method
public class GradesV3Redo
{
    public static void main(String[ ] args)
    {
        Scanner in = new Scanner(System.in);
        
        //prompts user to input student name
        System.out.println("Please enter the student's name: ");
        String studentName = in.next();
        System.out.println();
        
        //prompts user to input subject
        System.out.println("Please enter the subject name: ");
        String subjectName = in.next();
        System.out.println();
        
        //prompts the user to enter test scores
        System.out.println("Please enter the student's first test score: ");
        int score1 = in.nextInt();
        System.out.println("Please enter the student's second test score: ");
        int score2 = in.nextInt();
        System.out.println("Please enter the student's third test score: ");
        int score3 = in.nextInt();
        System.out.println();
        
        //calculates the total points and average for each score
        int totalPoints1 = score1;
        double averageGrade1 = totalPoints1 / 1.0;
        int totalPoints2 = score1 + score2;
        double averageGrade2 = totalPoints2 / 2.0;
        int totalPoints3 = score1 + score2 + score3;
        double averageGrade3 = totalPoints3 / 3.0;
        
        //prints the results
        System.out.println("Student name: " + studentName);
        System.out.println("Subject: " + subjectName);
        System.out.println();
        System.out.println("First test score: " + score1);
        System.out.println("Total points: " + totalPoints1);
        System.out.println("Average grade: " + averageGrade1);
        System.out.println();
        System.out.println("Second test score: " + score2);
        System.out.println("Total points: " + totalPoints2);
        System.out.println("Average grade: " + averageGrade2);
        System.out.println();
        System.out.println("Third test score: " + score3);
        System.out.println("Total points: " + totalPoints3);
        System.out.println("Average grade: " + averageGrade3);        
    }//end of main method
}//end of class