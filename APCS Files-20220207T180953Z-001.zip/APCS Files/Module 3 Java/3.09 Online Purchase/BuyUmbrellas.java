
/**
 * The purpose of this program is to simulate an online purchase by allowing
 * the user to input the information needed to purchase an umbrella, and
 * printing a receipt for them.
 *
 * @author Jack Moran
 * @version 9/3/17
 */
import java.util.Scanner; //imports scanner method
public class BuyUmbrellas
{
  public static void main (String [] args)
 {
    Scanner in = new Scanner(System.in); //sets up the scanner
    
    System.out.print("Thank you for choosing BrellaBoys! Please fill out ");
    System.out.println("the fields below to complete your order :)");
    System.out.print("Notice: Ours is a fragile program, so please be gentle ");
    System.out.println("by using the formats shown. Thank you!");
    System.out.println();
    
    //prompt to enter name
    System.out.print("First name: ");
    String firstName = in.next();
    System.out.println();
    System.out.print("Last name: ");
    String lastName = in.next();
    System.out.println();
    
    //prompt to enter date
    System.out.print("Date (mm/dd/yyyy): ");
    String date = in.next();
    System.out.println();
    
    //prompt to enter size and color of umbrella
    System.out.print("Umbrella size (Small/Medium/Large): ");
    String size = in.next();
    System.out.println();
    System.out.print("Umbrella color: ");
    String color = in.next();
    System.out.println();
    
    //prompt to enter price and quantity
    System.out.print("Price (00.00): ");
    String price = in.next();
    System.out.println();
    System.out.print("Quantity: ");
    String quantity = in.next();
    System.out.println();
    
    //prompt to enter debit card info
    System.out.print("Debit card number (#####-###-####): ");
    String cardNumber = in.next();
    System.out.println();
    System.out.print("Debit card PIN (#####): ");
    String cardPin = in.next();
    System.out.println();
    
    //creates an order number based on user input
    String orderNumber = lastName.substring(2, 5) + cardNumber.substring(6, 9);
    
    //calculates the total price and prepares the result for printing
    double numPrice = Double.parseDouble(price);
    double numQuantity = Double.parseDouble(quantity);
    double numTotalPrice = numPrice * numQuantity;
    String totalPrice = Double.toString(numTotalPrice);
    
    //prepares the name and debit card info for printing
    String initial = firstName.substring(0, 1) + ".";
    String censoredDebit = "#####-###-" + cardNumber.substring(10, 14);
    
    //prints the user's receipt
    System.out.println();
    System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
    System.out.println();
    System.out.println("Your order has been placed! Here is your e-Receipt:");
    System.out.println();
    System.out.println();
    System.out.println(initial + lastName);
    System.out.println(date);
    System.out.println(censoredDebit);
    System.out.println("Order number: " + orderNumber);
    System.out.println();
    System.out.println("Item ordered: " + size + " " + color + " umbrella");
    System.out.println("Price: " + price);
    System.out.println("Quantity : " + quantity);
    System.out.println("Total: " + totalPrice);
    System.out.println();
    System.out.println("Thanks again, and enjoy your new Brella!");
    System.out.println();
    System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
 }
}
