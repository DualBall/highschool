
/**
 * The purpose of this program is to calculate the user's Body Mass Index
 * based on the height and weight that they input.
 *
 * @author Jack Moran
 * @version 9/8/17
 */
import java.util.Scanner;
public class BMI
{
  public static void main (String [] args)
 {
   Scanner in = new Scanner(System.in); //sets up the scanner
   
   //Prompts the user to enter their name
   System.out.print("Enter your name (first last): ");
   String firstName = in.next();
   String lastName = in.next();
   System.out.println();
   
   //Prompts the user to enter their weight and height
   System.out.print("Enter your weight in pounds (e.g. 189): ");
   String weightLb = in.next();
   System.out.println();
   System.out.print("Enter your height in feet and inches (e.g. 5 11): ");
   String heightFt = in.next();
   String heightIn = in.next();
   System.out.println();
   
   //Converts the weight and height to metric units and calculates BMI
   double weight = Double.parseDouble(weightLb);
   double weightKg = weight * 0.453592;
   double height1 = Double.parseDouble(heightFt);
   double height2 = Double.parseDouble(heightIn);
   double heightM = (height1 * 0.3048) + (height2 * 0.0254);
   double bmi = weightKg / (heightM * heightM);
   
   //Prints everything but the weight status
   System.out.println();
   System.out.println("Body Mass Index Calculator");
   System.out.println("==========================");
   System.out.println("Name : " + firstName + " " + lastName);
   System.out.println("Height (m): " + heightM);
   System.out.println("Weight (kg): " + weightKg);
   System.out.println("BMI : " + bmi);
   
   //Uses boolean logic to determine and print the user's weight status
   if (bmi < 18.5)
     System.out.print("Category: Underweight");
   else if (bmi < 24.9)
     System.out.print("Category: Normal weight");
   else if (bmi < 29.9)
     System.out.print("Category: Overweight");
   else
     System.out.print("Category: Obese");
 }
}
