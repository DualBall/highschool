
/**
 * The purpose of this program is to calculate the user's total daily energy
 * expenditure (TDEE) based on their input.
 *
 * @author (Jack Moran)
 * @version (9/17/2017)
 */
import java.util.Scanner;
public class TDEE
{
  public static void main (String [] args)
 {
   Scanner in = new Scanner(System.in); //sets up the scanner
   
   //prints the header
   System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
   System.out.println();
   System.out.print("Welcome! Please fill out the fields below to ");
   System.out.println("calculate your TDEE");
   System.out.println();
   System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
   System.out.println();
   
   //prompts the user to enter name
   System.out.print("Please enter your name (first last): ");
   String firstName = in.next();
   String lastName = in.next();
   System.out.println();
   
   //prompts the user to enter BMR and gender
   System.out.println("Please enter your BMR: ");
   String sBMR = in.next();
   System.out.println();
   System.out.println("Please enter your biological gender (M/F): ");
   String genderEntry = in.next();
   boolean isMale = genderEntry.equalsIgnoreCase ("M");
   System.out.println();
   
   //prompts the user to enter activity level
   System.out.println("[A] : Resting (Sleeping, reclining)");
   System.out.println("[B] : Sedentary (Sitting/Lying down, minimal movement)");
   System.out.println("[C] : Light (Office work, sitting, walking");
   System.out.println("[D] : Moderate (cycling, gardening, other light labor)");
   System.out.println("[E] : Very Active (team sports, climbing, other hard labor)");
   System.out.println("[F] : Extremely Active (pro athlete, other heavy labor)");
   System.out.print("Based on the menu above, enter the letter for ");
   System.out.println("your activity level :");
   String activityEntry = in.next();
   double activityFactor = 0.0;
   System.out.println();
   
   //determines the activity factor based on user input
   if (activityEntry.equalsIgnoreCase ("A"))
   {
    activityFactor = 1.0;
   }
   
   else if (activityEntry.equalsIgnoreCase ("B"))
   {
    activityFactor = 1.3;
   }
   
   else if (activityEntry.equalsIgnoreCase ("C"))
   {
    if (isMale)
     {
      activityFactor = 1.6;
     }
    else
     {
      activityFactor = 1.5;
     }
   }
   else if (activityEntry.equalsIgnoreCase ("D"))
   {
    if (isMale)
     {
      activityFactor = 1.7;
     }
    else
     {
      activityFactor = 1.6;
     }
   }
   else if (activityEntry.equalsIgnoreCase ("E"))
   {
    if (isMale)
     {
      activityFactor = 2.1;
     }
    else
     {
      activityFactor = 1.9;
     }
   }
   else
   {
    if (isMale)
     {
      activityFactor = 2.4;
     }
    else
     {
      activityFactor = 2.2;
     }
   }
   
   //calculates the TDEE
   double numBMR = Double.parseDouble(sBMR);
   double numTDEE = numBMR * activityFactor;
   
   //prints the results
   System.out.println();
   System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
   System.out.println();
   System.out.println("Your results: ");
   System.out.println();
   System.out.println("Name: " + firstName + " " + lastName);
   
   if (isMale)
    {
     System.out.println("Gender: Male");
    }
   else 
    {
     System.out.println("Gender: Female");
    }
    
   System.out.println("BMR : " + numBMR + " calories");
   System.out.println("Activity factor: " + activityFactor);
   System.out.println("TDEE : " + numTDEE + " calories");
   System.out.println();
   System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
 }
}