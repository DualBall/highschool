
/**
 * The purpose of this program is to to calculate the probability that a
 * family with two children will consist of two boys, a boy and a girl,
 * or two girls. It then prints the results.
 *
 * @author Jack Moran
 * @version 09/20/17
 */
import java.util.Scanner;
import java.io.File;
import java.io.IOException;
public class Family
{
    public static void main(String[] args) throws IOException
    {
        //sets up variables
        String token = "";
        File fileName = new File("maleFemaleInFamily.txt");
        Scanner inFile = new Scanner(fileName);
        int totalFamilies = 0;
        int doubleBoys = 0;
        int doubleGirls = 0;
        int oneOfEach = 0;

        //while loop will continue while inFile has another line to read
        while( inFile.hasNext() )
        {
            token = inFile.next();
            if(token.equals("BB"))
	        {
	            doubleBoys++;
	        }
	    else if(token.equals("GG"))
	        {
	            doubleGirls++;
	        }
	    else
	        {
	            oneOfEach++;
	        }
	    totalFamilies++;
        }//end while

        inFile.close();                 //close input file
        
        //calculates the percentages of family types
        int percentDoubleB = (int)(((double)doubleBoys / totalFamilies) * 100);
        int percentDoubleG = (int)(((double)doubleGirls / totalFamilies) * 100);
        int percentDoubleOOE = (int)(((double)oneOfEach / totalFamilies) * 100);
        
        //prints the results
        System.out.print("Composition statistics for families with two");
        System.out.println(" children.");
        System.out.println();
        System.out.println("Total number of families: " + totalFamilies);
        System.out.println();
        System.out.println("Number of families with: ");
        System.out.println();
        System.out.print("2 boys : " + doubleBoys);
        System.out.println(" represents " + percentDoubleB + "%");
        System.out.print("2 girls : " + doubleGirls);
        System.out.println(" represents " + percentDoubleG + "%");
        System.out.print("1 boy and one girl : " + oneOfEach);
        System.out.println(" represents " + percentDoubleOOE + "%");
    }//end of main method
}//end of class