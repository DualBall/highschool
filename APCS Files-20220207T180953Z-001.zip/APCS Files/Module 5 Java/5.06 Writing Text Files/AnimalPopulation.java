
/**
 * The purpose of this program is to simulate the observation of an animal
 * population in an ecosystem.
 *
 * @author Jack Moran
 * @version 9/26/17
 */
import java.util.Scanner;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.File;
class AnimalPopulation
{
    public static void main (String [ ] args) throws IOException
    {
       //sets up the scanner, print writer and variables
       Scanner in = new Scanner(System.in);
       PrintWriter outFile = new PrintWriter(new File("counts.txt"));
       int trialNum = 0;
       int count = 0;
       
       //prompt user input
       System.out.println("Welcome to the Woodpecker Simulator!");
       System.out.println();
       
       //ensures the value entered is at least 1000       
       while (trialNum < 1000)
       {
          System.out.println("How many trials should be simulated?");
          System.out.print("Please enter a number greater than 1000: ");
          System.out.println();
       
          trialNum = in.nextInt();
       
          if (trialNum < 1000)
          {
              System.out.print("Please try again. Enter a number");
              System.out.println(" greater than 1000.");
          }
       }
       
       System.out.println("Simulating trials now, please wait a moment...");
       System.out.println();
       
       //carries out the trials and creates a file for the results
       for (int loop = 0; loop <= trialNum; loop++)
       {  
          for (double randNum = Math.random(); randNum < 0.75; count++)
           
           {randNum = Math.random();}
          
          outFile.println(count);
          //test System.out.println(count);
          count = 0;
       }

       outFile.close( ); //closes and completes the new file
       
       //prepares the file so the program can read it
       File fileName = new File("counts.txt");
       Scanner inFile = new Scanner(fileName);
       
       //calculates the total count by reading the file
       while (inFile.hasNext())
       {
          count += inFile.nextInt();
       }
       
       inFile.close( ); //closes the file again
       
       //calculates the average and prints the results
       double average = count / trialNum;
       
       System.out.println("Here are your results:");
       System.out.print("The average number of birds observed until ");
       System.out.print("spotting a woodpecker is: " + average);
    }
}