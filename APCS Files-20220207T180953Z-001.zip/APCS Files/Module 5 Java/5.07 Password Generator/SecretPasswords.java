
/**
 * The purpose of this program is to randomly generate a wide variety
 * of passwords.
 *
 * @author Jack Moran
 * @version 9/28/17
 */
import java.util.Scanner;
import java.util.Random;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.File;
class SecretPasswords
{
  public static void main (String [] args) throws IOException
  {
     //sets up the scanner, print writer, random number list and variables
     Scanner in = new Scanner(System.in);
     PrintWriter outFile = new PrintWriter(new File("passwords.txt"));
     Random randNumList = new Random();
     String userEntry = "0";
     int userInt = 0;
     String userLength = "0";
     int passLength = 0;
     int randNum = 0;
     int randNum2 = 0;
     String token = "";
       
     //prints the menu
     System.out.println("Password Generator Menu");
     System.out.println();
     System.out.println("-------------------------------------------------");
     System.out.println("[1]: Lowercase Letters");
     System.out.println("[2]: Uppercase Letters");
     System.out.println("[3]: Numbers and Symbols");
     System.out.println("[4]: Lowercase and Uppercase Letters");
     System.out.println("[5]: Quit");
     System.out.println("-------------------------------------------------");
     System.out.println();
       
     //prompts user selection
     System.out.println("Enter a selection (1-5): ");
     userEntry = in.next();
     userInt = Integer.parseInt(userEntry);
     
     //terminates everything if the entry is 5
     for (int loop = 0; userInt != 5; loop++)
     {
      //ensures that user selection is correct
       while ((userInt < 1) || (userInt > 5))
       {
         System.out.println("Invalid option, please try again.");
         System.out.println();
         System.out.println("Enter a selection (1-5): ");
         userEntry = in.next();
         userInt = Integer.parseInt(userEntry);
         System.out.println();
       }
         
      //makes sure the user's entry still isn't 5
       if (userInt != 5)
       {
        //prompts password length and ensures that it's correct
        while (passLength < 6)
        {
          System.out.println("Password length (6 or more): ");
          userLength = in.next();
          passLength = Integer.parseInt(userLength);
          System.out.println();
          
          if (passLength < 6)
          {
            System.out.println("Password is too short, please try again.");
            System.out.println();
          }
        }
        
        //generates the password based on user input
        if (userInt == 1)
        {
          for (int count = 0; count < passLength; count++)
          {
            randNum = randNumList.nextInt(25) + 97;
            outFile.print((char)randNum);
          }
        }
        if (userInt == 2)
        {
          for (int count = 0; count < passLength; count++)
          {
            randNum = randNumList.nextInt(25) + 65;
            outFile.print((char)randNum);
          }
        }
        if (userInt == 3)
        {
          for (int count = 0; count < passLength; count++)
          {
            randNum = randNumList.nextInt(18) + 48;
            outFile.print((char)randNum);
          }
        }
        if (userInt == 4)
        {
          for (int count = 0; count < passLength; count+= 2)
          {
            randNum = randNumList.nextInt(25) + 97;
            randNum2 = randNumList.nextInt(25) + 65;
            outFile.print((char)randNum);
            outFile.print((char)randNum2);
          }
        }
        
        outFile.println();
        System.out.println();
        
        //sets the next loop in motion
        System.out.println("Enter a selection (1-5): ");
        userEntry = in.next();
        userInt = Integer.parseInt(userEntry);
        passLength = 0;
        System.out.println();
       }
     }
     
     outFile.close( ); //closes and completes the new file
       
     //prepares the file so the program can read it
     File fileName = new File("passwords.txt");
     Scanner inFile = new Scanner(fileName);
     
     //reads the file and prints the results
     System.out.println("Thank you for using the password generator!");
     System.out.println();
     System.out.println("Here are your randomly generated passwords: ");
     
     while (inFile.hasNext())
     {
       token = inFile.next();
       System.out.println(token);
     }
  }
}
