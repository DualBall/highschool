
/**
 * Write a description of class temp here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class temp
{
   public static void main(String[] args) {
for(int outer = 0; outer < 4; outer++)
{
   for(int inner = 0; inner < 5; inner++)
   {
      System.out.print("∗");
   }
   System.out.println();
}

    }
 }
