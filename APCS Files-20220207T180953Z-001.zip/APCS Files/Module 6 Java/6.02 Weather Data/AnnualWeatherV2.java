
/**
 * The purpose of this program is to display the average temperature and
 * annual precipatation for a selected city (in this case, Orlando).
 * The user can choose whether to display the results in Farenheit or 
 * Celsius and in inches or centimeters.
 * 
 * @author Jack Moran
 * @version 10/3/17
 *
 */
import java.util.Scanner;
public class AnnualWeatherV2
{
    public static void main (String [ ] args)
    {
        //Declare and initialize variables
        Scanner in = new Scanner(System.in);
        String city = "Orlando";
        String state = "FL";
        int tempSum = 0;
        int precipSum = 0;
        double averageTemp = 0;
        String tempLabel = "F";
        String precipLabel = "in.";
        
        //prompts user input
        System.out.print("Choose the temperature scale (F = Farenheit, ");
        System.out.println("C = Celsius): ");
        String userTemp = in.next();
        System.out.print("Choose the precipitation scale (i = inches, ");
        System.out.println("c = centimeters: ");
        String userPrec = in.next();
  
        //sets up arrays
        String [] month = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul",
        "Aug", "Sep", "Oct", "Nov", "Dec"};
        
        double [] temperature = {60.9, 62.6, 67.4, 71.5, 77.1, 81.2, 82.4,
        82.5, 81.1, 75.3, 68.8, 63.0}; //initialize with Fahrenheit values
        
        for( int index = 0; index < temperature.length && 
        userTemp.equalsIgnoreCase("C"); index++)
        {
          temperature[index] = (temperature[index] - 32) * .6;
          tempLabel = "C";
          //Note: .6 is an approximation designed to reduce decimal clutter
        }//initialize with Celsius values
        
        double [] precipitation = {2.4, 2.4, 3.5, 2.4, 3.7, 7.4, 7.2, 6.3,
        5.8, 2.7, 2.3, 2.3};  //initialize with inch values
        
        for( int index = 0; index < precipitation.length && 
        userPrec.equalsIgnoreCase("C"); index++)
        {
          precipitation[index] = precipitation[index] * 2.54;
        }//initialize with centimeter values
        
        //calculates average temperature and total precipitation
        for( int index = 0; index < temperature.length; index++)
        {
          tempSum += temperature[index];
          precipSum += precipitation[index];
          
          if (index == 11)
          {
           averageTemp = tempSum / 12.0;
          }
        }
    
        //prints the output
        System.out.println();
        System.out.println("\t\tWeather Data");
        System.out.printf("%28s%n", city + ",  " + state);
        System.out.println();
        System.out.print("Month     Temperature (" + tempLabel + ")");
        System.out.println("     Precipitation (" + precipLabel + ")");
        System.out.println("***************************************************");
        for( int index = 0; index < temperature.length; index++)
        {
          System.out.printf(month[index] + "%16.2f", temperature[index]);
          System.out.printf("%22.2f\n", precipitation[index]);
        }
        System.out.println("***************************************************");
        System.out.printf("Average temperature: %1.2f ", averageTemp);
        System.out.print(tempLabel + "  Annual precip.: " + precipSum);
        System.out.print(" " + precipLabel);
    }//end main
}//end class