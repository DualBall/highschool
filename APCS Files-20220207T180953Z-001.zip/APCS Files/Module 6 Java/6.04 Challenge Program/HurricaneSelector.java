
/**
 * The purpose of this program is to read hurricane data in from a file,
 * allow the user to select what range of data they'll see, display the data
 * in a neat fashion, and create a new file containing a summary of the data.
 *
 * @author Jack Moran
 * @version 10/4/17
 */
import java.util.Scanner;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.File;
public class HurricaneSelector
{
  public static void main (String [] args) throws IOException
  {
     //prepares the file for reading and initializes variables
     File fileName = new File("HurricaneData.txt");
     Scanner inFile = new Scanner(fileName);
     int arrayNum = 0;
     double catSum = 0.0;
     double windSum = 0.0;
     double pressureSum = 0.0;
     int cat1Sum = 0;
     int cat2Sum = 0;
     int cat3Sum = 0;
     int cat4Sum = 0;
     int cat5Sum = 0;
     String token = "";
     
     //sets up arrays
     while (inFile.hasNextLine())
     { 
      token = inFile.nextLine();
      arrayNum++;
     }
     inFile.close();
     inFile = new Scanner(fileName);
     
     int [] years = new int[arrayNum];
     String [] months = new String[arrayNum];
     int [] pressures = new int[arrayNum];
     double [] windSpeedKts = new double[arrayNum];
     String [] names = new String[arrayNum];
     double [] windSpeedMph = new double[arrayNum];
     int [] categories = new int[arrayNum];
     
     //reads in the file data
     for (int index = 0; inFile.hasNextLine(); index++)
     {
       years[index] = Integer.parseInt(inFile.next());
       months[index] = inFile.next();
       pressures[index] = Integer.parseInt(inFile.next());
       windSpeedKts[index] = Double.parseDouble(inFile.next());
       names[index] = inFile.next();
     }
     
     //converts the wind speeds from kts to mph
     for (int index = 0; index < windSpeedMph.length; index++)
       windSpeedMph[index] = windSpeedKts[index] * 1.15078;
       
     //determines the categories of each storm
     for (int index = 0; index < categories.length; index++)
     {
       if (windSpeedMph[index] < 95)
       categories[index] = 1;
       else if (windSpeedMph[index] < 110)
       categories[index] = 2;
       else if (windSpeedMph[index] < 129)
       categories[index] = 3;
       else if (windSpeedMph[index] < 156)
       categories[index] = 4;
       else
       categories[index] = 5;
     }
     
     //closes the file scanner and sets up a user input scanner
     inFile.close();
     Scanner in = new Scanner(System.in);
     
     //prompts user input
     System.out.println("Data for 1995 - 2015 is available. Please input the");
     System.out.print(" range of years you'd like data for (e.g. 1998 2005): ");
     int userMin = Integer.parseInt(in.next());
     int userMax = Integer.parseInt(in.next());
     
     //prints an error message if user input is incorrect
     while (userMin < 1995 || userMax > 2015)
     {
       System.out.println("Selected range is invalid; please try again.");
       System.out.print("Data for 1995 - 2015 is available. Please input the");
       System.out.print("range of years you'd like data for (e.g. 1998 2005)");
       userMin = Integer.parseInt(in.next());
       userMax = Integer.parseInt(in.next());
       System.out.println();
     }
     
     //calculates the average for category, wind speed and pressure
     for (int category : categories)
      catSum += category;
     double catAverage = catSum / arrayNum;
     
     for (double speed : windSpeedMph)
      windSum += speed;
     double windAverage = catSum / arrayNum;
     
     for (double pressure : pressures)
      pressureSum += pressure;
     double pressureAverage = pressureSum / arrayNum;
     
     //finds the minimum and maximum for category, wind speed and pressure
     int catMin = Integer.MAX_VALUE;
     int catMax = Integer.MIN_VALUE;
     for(int category : categories)
     {
       if (category < catMin)
        catMin = category;
       if (category > catMax)
        catMax = category;
     }
     
     double mphMin = Double.MAX_VALUE;
     double mphMax = Double.MIN_VALUE;
     for(double speed : windSpeedMph)
     {
       if (speed < mphMin)
        mphMin = speed;
       if (speed > mphMax)
        mphMax = speed;
     }
     
     int mbMin = Integer.MAX_VALUE;
     int mbMax = Integer.MIN_VALUE;
     for(int pressure : pressures)
     {
       if (pressure < mbMin)
        mbMin = pressure;
       if (pressure > mbMax)
        mbMax = pressure;
     }
     
     //prints the results
     System.out.printf("%26d - %d Hurricane Data\n\n", userMin, userMax);
     System.out.print(" Year\t Hurricane\tCategory\t Pressure (mb)\t ");
     System.out.println("Wind Speed (mph)");
     System.out.print("====================================================");
     System.out.println("=====================");
     
     for (int index = 0; index < years.length; index++)
     {
       if(years[index] >= userMin && years[index] <= userMax)
       { 
         System.out.printf(" %d\t %-9s\t %3d\t\t %6d %16.2f\n", years[index],
         names[index], categories[index], pressures[index],
         windSpeedMph[index]);
       }
     }
     
     System.out.print("====================================================");
     System.out.println("=====================");
     System.out.printf(" \t Average:\t%6.1f\t\t%9.1f\t%8.2f\n",
     catAverage, pressureAverage, windAverage);
     System.out.printf(" \t Minimum:\t%4d\t\t%7d\t\t%8.2f\n",
     catMin, mbMin, mphMin);
     System.out.printf(" \t Maximum:\t%4d\t\t%7d\t\t%8.2f\n",
     catMax, mbMax, mphMax);
     System.out.println();
     
     //calculates and prints the category summary
     for (int category : categories)
     {
       if (category == 1)
       cat1Sum++;
       else if (category == 2)
       cat2Sum++;
       else if (category == 3)
       cat3Sum++;
       else if (category == 4)
       cat4Sum++;
       else
       cat5Sum++;
     }
     
     System.out.println("Summary of Categories:");
     System.out.printf("   Cat 1:%3d", cat1Sum);
     System.out.printf("   Cat 2:%3d", cat2Sum);
     System.out.printf("   Cat 3:%3d", cat3Sum);
     System.out.printf("   Cat 4:%3d", cat4Sum);
     System.out.printf("   Cat 5:%3d", cat5Sum);
     
     //prints the category summary to a new file
     PrintWriter outFile = new PrintWriter(new File("summary.txt"));
     outFile.println(userMin + " - " + userMax + " Category Summary");
     outFile.println("Cat 1: " + cat1Sum);
     outFile.println("Cat 2: " + cat2Sum);
     outFile.println("Cat 3: " + cat3Sum);
     outFile.println("Cat 4: " + cat4Sum);
     outFile.println("Cat 5: " + cat5Sum);
     outFile.close();
  }
}