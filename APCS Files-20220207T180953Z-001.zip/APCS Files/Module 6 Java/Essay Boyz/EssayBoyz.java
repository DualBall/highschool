
/**
 * Write a description of class EssayBoyz here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class EssayBoyz
{
   public static void main (String [] args)
   {
      double [] timeScores = {24.6, 23.4, 21.7, 27.8, 22.7, 22.4, 23.9};
double min = Double.MAX_VALUE;
double max = Double.MIN_VALUE;
for(int i = 0; i < timeScores.length; i++)
 {
   if (timeScores[i] < min)
   min = timeScores[i];
   if (timeScores[i] > max)
   max = timeScores[i];
 }

double timeSum = 0.0;
for(int i = 0; i < timeScores.length; i++)
{
 if(timeScores[i] != min && timeScores[i] != max)
 {
   timeSum += timeScores[i];
 }
}
double timeAverage = timeSum / timeScores.length;

System.out.print("Time scores: ");
for(int i = 0; i < timeScores.length; i++)
{
 if(timeScores[i] != min && timeScores[i] != max)
 {
   System.out.print(timeScores[i]);
 }
}
System.out.println();

System.out.println("Average: " + timeAverage);      
   }
}
