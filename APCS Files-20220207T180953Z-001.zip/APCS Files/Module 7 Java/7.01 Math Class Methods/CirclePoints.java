
/**
 * The purpose of this program is to calculate the coordinates of points on a
 * circle with a given radius.
 *
 * @author (Jack Moran)
 * @version (10/13/17)
 */
public class CirclePoints
{
  public static void main (String [] args)
  {
    //sets up variables
    double radius = 1.0; //sets the adjustable radius
    double y1;
    double y2;
    double ySquared;
    
    //prints the header
    System.out.println("Points on a circle with a radius of " + radius);
    System.out.println("      x1       y1       x1       y2");
    System.out.println("****************************************");
    
    //performs the coordinate calculations and prints the results
    for (double x1 = 1.00; x1 >= -1.00; x1 -= 0.10)
    {
      ySquared = Math.pow(radius, 2) - Math.pow(x1, 2);
      y1 = Math.sqrt(ySquared);
      y2 = -(y1);
      System.out.printf("%8.2f%9.2f%9.2f%9.2f\n", x1, y1, x1, y2);
    }
  }
}
