
 /**
 * The purpose of this program is to determine the surface gravity of each
 * planet in our solar system.
 *
 * @author (Jack Moran)
 * @version (10/15/17)
 */
 import java.io.IOException;
 import java.io.PrintWriter;
 import java.io.File;
 public class PlanetGravity
 { 
   //calculates radius
   public static double diaToRadius(double x)
   {
     double radius = (x * 1000) / 2;
     return radius;
   }
   
   //calculates gravity
   public static double gravityCalc (double m, double r)
   {
     double gc = 6.67e-11;
     double result = (gc * m) / (Math.pow(r, 2));
     return result;
   }
   
   //creates a file for the gravity data
   public static void gravPrint (double[] gravities) throws IOException
   {
     PrintWriter outFile = new PrintWriter(new File("gravity.txt"));
     for (double grav : gravities)
     outFile.printf("%4.2f%n", grav);
     outFile.close();
     return;
   }
   
   //starts the main method
   public static void main (String [] args) throws IOException
   {
     //sets up the arrays for planets, diameter and mass
     String[] planets = {"Mercury", "Venus", "Earth", "Mars", "Jupiter", 
     "Saturn", "Uranus", "Neptune"};
     double[] diameter = {4880.0, 12103.6, 12756.3, 6794.0, 142984.0, 
     120536.0, 51118.0, 49532.0};
     double[] mass = {3.30e23, 4.869e24, 5.972e24, 6.4219e23, 1.900e27,
     5.68e26, 8.683e25, 1.0247e26};
     
     //sets up the arrays for radius and gravity
     double [] radius = new double[diameter.length];
     double [] gravity = new double[planets.length];
     
     for (int i = 0; i < radius.length; i++)
     radius[i] = diaToRadius(diameter[i]);
     for (int i = 0; i < planets.length; i++)
     gravity[i] = gravityCalc(mass[i], radius[i]);
     
     //prints the header
     System.out.println("                        Planetary Data");
     System.out.print("  Planet       Diameter (km)      Mass (kg)     ");
     System.out.println("g (m/s^2)  ");
     System.out.print("-------------------------------------------------");
     System.out.println("----------");
     
     //prints the data
     for (int i = 0; i < planets.length; i++)
       System.out.printf("%9s%14.0f%19.2E%13.2f\n", planets[i], diameter[i],
       mass[i], gravity[i]);
       
     //triggers the printwriter method
     gravPrint(gravity);
   }
 }
