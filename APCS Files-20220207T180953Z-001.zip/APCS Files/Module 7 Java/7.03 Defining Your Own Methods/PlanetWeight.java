
/**
 * The purpose of this program is to use the gravity calculated in the
 * previous program to calculate the user's weight on each planet in the
 * solar system.
 *
 * @author (Jack Moran)
 * @version (10/16/17)
 */
import java.util.Scanner;
import java.io.File;
import java.io.IOException;
public class PlanetWeight
{
  //reads in the gravity data
  public static void gravReader(double [] gravities) throws IOException
  {
    File fileName = new File("gravity.txt");
    Scanner inFile = new Scanner(fileName);
    for (int i = 0; i < gravities.length; i++)
    gravities[i] = Double.parseDouble(inFile.next());
    return;
  }
  
  //uses user input to calculate weight
  public static double weightCalc(double grav, double userLbs)
  {
    double result = ((userLbs * 433.59237) * (grav / 9.79)) / 433.59237;
    return result;
  }
  
  //starts the main method
  public static void main(String[] args) throws IOException
  {
    //sets up the scanner and arrays
    Scanner in = new Scanner(System.in);
    String[] planets = {"Mercury", "Venus", "Earth", "Mars", "Jupiter", 
    "Saturn", "Uranus", "Neptune"};
    double [] gravity = new double[planets.length];
    
    gravReader(gravity);
    
    //prompts user input
    System.out.print("Enter your exact weight to the decimal (i.e. 100.0): ");
    double userEntry = Double.parseDouble(in.next());
    System.out.println("\n");
    
    //prints the header
    System.out.println("       My Weight on the Planets");
    System.out.println("  Planet     Gravity     Weight (lbs)  ");
    System.out.println("--------------------------------------");
    
    //prints the data
    for (int i = 0; i < planets.length; i++)
    System.out.printf("  %-7s%9.2f%17.2f%n", planets[i], gravity[i],
    weightCalc(gravity[i], userEntry));
  }
}
