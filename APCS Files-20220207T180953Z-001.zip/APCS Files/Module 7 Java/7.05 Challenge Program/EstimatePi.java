
/**
 * The purpose of this program is to calculate the value of pi by throwing
 * darts at a dart board.
 *
 * @author (Jack Moran)
 * @version (10/17/17)
 */
import java.util.Scanner;
public class EstimatePi
{
  //performs the calculations for each trial
  public static double trialSim (int dartCount)
  {
    double hits = 0;
    for (int i = 0; i < dartCount; i++)
    {
      if (Math.pow(Math.random(), 2) + Math.pow(Math.random(), 2) <= 1)
      hits ++;
    }
    double result = 4 * (hits / dartCount);
    return result;
  }
    
  //sets up the main method
  public static void main (String [] args)
  {
    //sets up the scanner and variables
    Scanner in = new Scanner(System.in);
    double piSum = 0.0;
    double currentPi = 0.0;
    
    //prompts user input
    System.out.print("Enter the amount of darts per trial: ");
    int trialDarts = Integer.parseInt(in.next());
    System.out.println();
    System.out.print("Enter the amount of trials: ");
    int trialNum = Integer.parseInt(in.next());
    System.out.println();
    
    //prints the results
    for (int i = 1; i <= trialNum + 1; i++)
    {
      if (i < trialNum + 1)
      {
        currentPi = trialSim(trialDarts);
        System.out.printf("Trial [%2d]: pi = %8.6f%n", i, currentPi);
        piSum += currentPi;
      }
      else
      System.out.printf("Estimate of pi = %8.6f", piSum / trialNum);
    }
  }
}
