
/**
 * The purpose of this program is to create a dog-themed object that will be
 * "fed" and "walked" twice each day.
 *
 * @author (Jack Moran)
 * @version (10/24/17)
 */
public class DogV3
{
     //default constructor
    public DogV3()
    {
    }

    //calculate how many times the dog should be fed
    public int calcFeed(int dayNum)
    {
        return dayNum * 2;
    }
    //calculate how many walks the dog should have
    public int calcWalk(int dayNum)
    {
        return dayNum * 2;
    }

    //main method
    public static void main(String[] args)
    {
        //declaration of variables
        int days = 2, feedNum, walkNum; 

        DogV3 dog = new DogV3();

        //call methods
        feedNum = dog.calcFeed(days);
        walkNum = dog.calcWalk(days);

        //prints results
        System.out.print("Over the course of " + days + " days, the dog");
        System.out.print("should be fed " + feedNum + " times and walked ");
        System.out.println(walkNum + " times.");
    }
}
