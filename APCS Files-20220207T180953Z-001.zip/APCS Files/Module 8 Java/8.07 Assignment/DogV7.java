
/**
 * This program creates the methods that will run the dog program. These
 * methods calculate how much the dog object should be fed and walked
 * over the course of the given number of days.
 *
 * @author (Jack Moran)
 * @version (11/1/17)
 */
public class DogV7
{
    //initializes private variables
    private double kgNum, walkNum;
    
    //default constructor
    DogV7(double kg, double walk)
    {
      kgNum = kg;
      walkNum = walk;
    }
    
    //calculate how many kilograms of food the dog should be fed
    public double dailyCalc(double dailyNum, int dayTotal)
    {
        return dailyNum * (double)dayTotal;
    }
    //calculate how many walks the dog should have
    public int dailyCalc(int dailyNum, int dayTotal)
    {
        return dailyNum * dayTotal;
    }
}
