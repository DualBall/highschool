
/**
 * This program provides the commands to run DogV7 with the given values.
 *
 * @author (Jack Moran)
 * @version (11/1/17)
 */
public class DogV7Client
{
  public static void main(String[] args)
  {
    //declaration of variables
    int days = 2, walks = 2, walkNum;
    double kg = 9.07, kgNum;
    
    //creates objects and calls methods
    DogV7 dailyFood = new DogV7(kg, days);
    DogV7 dailyWalks = new DogV7(walks, days);
    
    kgNum = dailyFood.dailyCalc(kg, days);
    walkNum = dailyWalks.dailyCalc(walks, days);
    //prints results
    System.out.print("Over the course of " + days + " days, the dog");
    System.out.printf(" should be fed %4.2f kilograms of food", kgNum);
    System.out.println(" and walked " + walkNum + " times.");
    }
}
