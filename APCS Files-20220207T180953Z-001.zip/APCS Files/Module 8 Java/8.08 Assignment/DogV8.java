
/**
 * This program creates the methods that will run the dog program. These
 * methods calculate how many times each dog should be fed and walked over 
 * a random amount of time (up to 21 days) based on given values for each
 * dog. These methods also work with arrays of values.
 * 
 * @author (Jack Moran)
 * @version (11/2/17)
 */
import java.util.Random;
public class DogV8
{
    //initializes variables and sets up random utility
    private int foodNum, walkNum, dayNum, foodTotal, walkTotal;
    Random rn = new Random();  
    
    //default constructor
    DogV8(int food, int walk)
    {
      foodNum = food;
      walkNum = walk;
    }
      
    //calculates random number of days
    public void daySet()
    {
      dayNum = rn.nextInt(21) + 1;
    }
    
    //retrieves the number of days for the client to input
    public int dayGet()
    {
      return dayNum;
    }
    
    //calculate how many kilograms of food the dog should be fed
    public int foodCalc(int totalDays)
    {
      return foodNum * totalDays;
    }
    //calculate how many walks the dog should have
    public int walkCalc(int totalDays)
    {
        return walkNum * totalDays;
    }
    //prints each object's set of values
    public String toString(String name, int foodTotal, int walkTotal)
    {
      return String.format(" %-12s%15d%11d", name, foodTotal, walkTotal);
    }
}
