
/**
 * This program provides the commands to run DogV8 with the given array.
 *
 * @author (Jack Moran)
 * @version (11/2/17)
 */
public class DogV8Client
{
  public static void main(String[] args)
  {
    //declaration of variables
    int days = 1, foodMin = Integer.MAX_VALUE, foodMax = Integer.MIN_VALUE,
    walkMin = Integer.MAX_VALUE, walkMax = Integer.MIN_VALUE, foodSum = 0,
    walkSum = 0;
    String [] dogNames = {"Sophie", "Rebecca", "Rascal", "Dotsuku", "Rusta"};
    int [] foodSet = new int[dogNames.length];
    int [] walkSet = new int[dogNames.length];
    
    //creates object array
    DogV8[] dogs = {new DogV8(2, 2),
                    new DogV8(3, 1),
                    new DogV8(2, 3),
                    new DogV8(2, 2),
                    new DogV8(3, 3)};
    
    //calls methods
    dogs[1].daySet();
    days = dogs[1].dayGet();
    
    for (int i = 0; i < dogNames.length; i++)
    {
      foodSet[i] = dogs[i].foodCalc(days);
      walkSet[i] = dogs[i].walkCalc(days);
    }
    
    //prints the header
    System.out.printf(" Name     Days: %2d     Feedings     Walks %n", days);
    System.out.println("--------------------------------------------");
    
    //calls the toString method
    for (int i = 0; i < dogNames.length; i++)
    {
      System.out.println(dogs[i].toString(dogNames[i], foodSet[i], 
      walkSet[i]));
    }
    
    System.out.println("--------------------------------------------");
    
    //calculates the minimum, maximum and average for feedings and walks
    for (int food : foodSet)
    {
      if (food < foodMin)
       foodMin = food;
      if (food > foodMax)
       foodMax = food;
    }
    for (int walk : walkSet)
    {
      if (walk < walkMin)
       walkMin = walk;
      if (walk > walkMax)
       walkMax = walk;
    }
    for (int food : foodSet)
     foodSum += food;
    for (int walk : walkSet)
     walkSum += walk;
    int foodAverage = foodSum / foodSet.length;
    int walkAverage = walkSum / walkSet.length;
    
    //prints the results
    System.out.print(" Minimum feedings: " + foodMin + "     ");
    System.out.println("Minimum walks : " + walkMin);
    System.out.print(" Maximum feedings: " + foodMax + "     ");
    System.out.println("Maximum walks : " + walkMax);
    System.out.print(" Average feedings: " + foodAverage + "     ");
    System.out.println("Average walks : " + walkAverage);
    }
}
