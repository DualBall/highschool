
/**
 * @purpose: This class calculates CO2 emitted for each gallon of gas consumed
 * by a car.
 * It contains mutator methods to calculate tons of CO2 emitted and to convert
 * tons to pounds.
 * It contains getter methods for gallons, tons and pounds.
 * Private instance variables include myGallonsUsed, myTonsCO2, and myPoundsCO2.
 * 
 * @author: Jack Moran
 * @version: 11/3/17
 */
public class CO2FootprintV2
{
    //declaration of private variables
    private double myGallonsUsed, myTonsCO2, myPoundsCO2;

    /**
     * Constructor for objects of type ShapesV9
     * @param gallons gallons of gas used
     * Precondition: gallons is a positive value
     */
    CO2FootprintV2(double gallons)
    {
        myGallonsUsed = gallons;
    }

    /**
     * Mutator method to calculate tons of CO2 emitted (no parameters).
     */
    public void calcTonsCO2()
    {
        myTonsCO2 = (8.78 * Math.pow(10, -3)) * myGallonsUsed;
    }

    /**
     * Mutator method to convert tons of CO2 to pounds (no parameters).
     */
    public void convertTonsToPounds()
    {
        myPoundsCO2 = myTonsCO2 * 2205;
    }

    /**
     * Getter method to return the gallons of gas used (no parameters).
     * @return gallons of gas used.
     */
    public double getGallons()
    {
        return myGallonsUsed;
    }

    /**
     * Getter method to return the tons of CO2 emitted (no parameters).
     * @return tons of CO2 emitted.
     */
    public double getTonsCO2()
    {
        return myTonsCO2;
    }

    /**
     * Getter method to return the pounds of CO2 emitted (no parameters).
     * @return pounds of CO2 emitted.
     */
    public double getPoundsCO2()
    {
        return myPoundsCO2;
    }
}
