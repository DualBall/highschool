
/**
 * @purpose: Runs the methods from CO2FootprintV2 using the given amount of
 * gas and prints the results.
 *
 * @author: Jack Moran
 * @version: 11/3/17
 */
public class CO2FootprintV2Tester
{
    public static void main(String[] args)
    {
        //sets the gallons of gas
        double gallonsOfGas = 2410;

        //creates the object and calls methods
        CO2FootprintV2 footprint = new CO2FootprintV2(gallonsOfGas);
        footprint.calcTonsCO2();
        footprint.convertTonsToPounds();
        
        //prints the results
        System.out.println("           CO2 Emissions");
        System.out.println("  Gallons   Pounds      Tons");
        System.out.println("  of Gas   from Gas   from Gas");
        System.out.println("  ****************************");
        System.out.printf("  %6.1f   %8.2f    %6.3f", footprint.getGallons(),
                                                      footprint.getPoundsCO2(),
                                                      footprint.getTonsCO2());

        System.out.println();
    }
}

