
/**
 * @purpose Estimates the value of pi by simulating trials of throwing darts
 * at a board.
 *
 * @author (Jack Moran)
 * @version (11/10/17)
 */
public class EstimatePiV2
{
  private double minPi = Double.MAX_VALUE, maxPi = Double.MIN_VALUE;
  private int darts;
  
  /**
   * Constructor for objects of type EstimatePi
   * @param darts number of darts thrown in each trial
   */
  EstimatePiV2(int dartCount)
  {
    darts = dartCount;
  }
  
  /**
   * Mutator method to perform the calculations for each trial (no parameters)
   */
  public double trialSim ()
  {
    double hits = 0;
    for (int i = 0; i < darts; i++)
    {
      if (Math.pow(Math.random(), 2) + Math.pow(Math.random(), 2) <= 1)
      hits ++;
    }
    double result = 4 * (hits / darts);
    return result;
  }
  
  /**
   * Mutator method to set the current minimum and maximum values of pi
   * @param currPi the estimation of pi from the latest trial
   */
  public void piCalc(double currPi)
  {
    if (currPi < minPi)
    minPi = currPi;
    if (currPi > maxPi)
    maxPi = currPi;
  }
  
  /**
   * Getter method to retrieve the minimum pi value (no parameters)
   */
  public double getMin ()
  {
    return minPi;
  }
  
  /**
   * Getter method to retrieve the maximum pi value (no parameters)
   */
  public double getMax ()
  {
    return maxPi;
  }
  
  /**
   * toString method to print the result of each trial; designed to work with
   * for loops
   * @param i index of the for loop
   * @param currPi the estimation of pi from the latest trial
   */
  public String toString(int i, double currPi)
  {
    return String.format("Trial [%2d]: pi = %8.6f%n", i, currPi);
  }
}
